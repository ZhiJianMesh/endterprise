export default {
en:{
app_name:"employees management",
failToCall:"Failed",
close:"Close",
ok:"OK",
account:"Account",
role:"Role",
pwd:"Password",
createAt:"Create at",
name:"Name",
descr:"Description",
addMbr:"Add employee",
crtGrp:"Create group",
owner:"Owner"
},
cn:{
app_name:"雇员管理",
failToCall:"调用失败",
close:"关闭",
ok:"确定",
account:"帐号",
role:"角色",
pwd:"密码",
createAt:"创建时间",
name:"名称",
descr:"描述",
addMbr:"增加雇员",
crtGrp:"创建组织",
owner:"管理员"
}
}