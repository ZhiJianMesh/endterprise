const _btnWidth=150;
const _winWidth=document.documentElement.clientWidth;
const _winHeight=document.documentElement.clientHeight;
const _canvasHeight = _winHeight;
const _canvasWidth = _winWidth<_winHeight?_winWidth:(parseInt(_winHeight*320/568)); //px
//-------------------------------------------游戏逻辑
var _canvas,_brush,_bufferedCanvas,_bufferedBrush;
var _bulletVoice,_bgMusic,_gameOverMusic,_e3CrushVoice;
const _visionSpeed = 0.5; //视界速度，背景移动速度

const _gunNumber = 1; //枪数量
const _enemies = []; //敌机
const _booms = [];   //爆炸点
const _bullets = []; //子弹
var _visionY = 0;//背景位置
var _isMoving=false;


//基本函数
const _drawImage=(x, y, img, w, h)=>{
    if(img.complete){
        _canvasDrawImg(img, x, y, w, h);
    }else{
        img.onload = ()=>{
            _canvasDrawImg(img, x, y, w, h);
        }
    }
}

const _canvasDrawImg = (img, x, y, w, h) => {
    if(w && h) {
        _bufferedBrush.drawImage(img, x, y, w, h);
    } else {
        _bufferedBrush.drawImage(img, x, y);
    }
}

//将缓存画布中内容输出到可见的画布中
const _validate = () => {
    _brush.drawImage(_bufferedCanvas, 0, 0);
}

const HERO = {
    x:0,
    y:0,
    x0:0,
    y0:0,
    life:10,  //生命值，经过多少次撞击后死掉
    score:0,   //得分
    img:new Image()
};
const ENEMY_OK = 0;
const ENEMY_BEHIT = 1.5; //被击中
const ENEMY_FALL  = 2;   //掉落
const ENEMY_CRASH = 3;   //坠毁
const ENEMY1 = {   //小敌机
    x:0,         //x坐标
    y:0,         //y坐标
    x0:0,        //图片原点，宽度的一半
    y0:0,        //图片原点，高度的一半
    life:1,      //打死它需要的子弹数
    score:1,     //击中一次的得分
    speed:4,     //每次移动的像素数量
    foreTime:0,  //记录前一次缩小图片时间
    state:ENEMY_OK, //状态，0：正常，1：击中，2：掉落，3：坠毁
    img:new Image() //图片
};
const ENEMY2 = { //中敌机
    x:0,
    y:0,
    x0:0,
    y0:0,
    life:5,  
    score:2,
    speed:3,
    foreTime:0,       //记录前一次缩小图片时间
    state:ENEMY_OK,
    img:new Image()
};
const ENEMY3 = { //大敌机
    x:0,
    y:0,
    x0:0,
    y0:0,
    life:15,
    score:5,
    speed:3,
    foreTime:0,//记录前一次缩小图片时间
    state:ENEMY_OK,
    img:new Image()
};

const BOOM_FIRE = 1; //起爆
const BOOM_BLAST = 1.5;
const BOOM_VANISH = 2;
const BOOM = { //爆炸烟雾
    x:0,
    y:0,
    x0:0,
    y0:0,
    foreTime:0,       //记录前一次放大爆炸图片时间
    state:BOOM_FIRE,  //状态，0：起爆，1：炸开，2：消失
    img:new Image()
};

const BULLET = {//子弹
    x:0,
    y:0,
    x0:0,
    y0:0,
    speed:3,
    img:new Image()
};

const START_BG=new Image();
START_BG.src = "airbattle/imgs/bg_start.png";
START_BG.onload = ()=>{
 //   _drawImage(0, 0, START_BG, _canvasWidth, _canvasHeight);
 //   _validate();
};
const GAME_BG=new Image();
GAME_BG.src = "airbattle/imgs/bg_game.png";
ENEMY1.img.src = "airbattle/imgs/enemy1.png";
ENEMY1.img.onload = () => {
    _imgLoaded(ENEMY1);
};

ENEMY2.img.src = "airbattle/imgs/enemy2.png";
ENEMY2.img.onload = () => {
    _imgLoaded(ENEMY2);
};

ENEMY3.img.src = "airbattle/imgs/enemy3.png";
ENEMY3.img.onload = () => {
    _imgLoaded(ENEMY3);
};

BOOM.img.src = "airbattle/imgs/boom.png";
BOOM.img.onload = () => {
    _imgLoaded(BOOM);
};

HERO.img.src = "airbattle/imgs/hero.png";
HERO.img.onload = () => {
    _imgLoaded(HERO);
};

BULLET.img.src = "airbattle/imgs/bullet.png";
BULLET.img.onload = () => {
    _imgLoaded(BULLET);
};

const _imgLoaded = img => { //记录图片中间的位置，避免每次都计算
    img.x0 = img.img.width / 2;
    img.y0 = img.img.height / 2;
}

const _clone = tmpl => {
    var o = {};
    for(var i in tmpl) {
        o[i] = tmpl[i];
    }
    return o;
}

const SHOOT_STATE = {
    interval:200,  //增加子弹的时间间隔
    foreTime:0     //上次增加子弹的时间点
};
const ENEMY_STATE = {
    interval:500,  //增加敌机时间间隔
    foreTime:0,    //上次增加敌机的时间点
    
    fallTime:400,  //坠落时间间隔
    boomTime:300,  //爆炸时间间隔
    
    chance1:55,    //敌机1出现概率
    chance2:90,    //-chance1为敌机2出现概览
    chance3:100,
};

const _game = () => {
    _bgMusic.play();
    _bulletVoice.play();
    _handleGame();
    _drawGame();
    if(HERO.life <= 0) { //生命值为0时，游戏结束
        _gameOver();
    }
}

const _handleGame = () => { //处理游戏逻辑，移动与射击判断，只做数据处理
    var bullet;
    var num = _gunNumber;
    var time = new Date().getTime();
    //发射子弹
    if(time - SHOOT_STATE.foreTime >= SHOOT_STATE.interval) {
        SHOOT_STATE.foreTime = time;
        if(num % 2 == 1) {//奇数个，中间固定放一个
            bullet = _clone(BULLET);
            bullet.x = HERO.x + HERO.x0 - bullet.x0;
            bullet.y = HERO.y - bullet.y0;
            _bullets.push(bullet);
            num--;
        }
        
        if(num > 0) {
            var space = HERO.img.x0 / num;
            var pos = 0;
            var x1 = HERO.x + HERO.img.width;
            for(var i = 0; i < num; i+=2) { //两边匀称的放置枪
                bullet = _clone(BULLET);
                bullet.x = HERO.x + pos;
                bullet.y = HERO.y - bullet.y0;
                _bullets.push(bullet);
                
                bullet = _clone(BULLET);
                bullet.x = x1 - pos;
                bullet.y = HERO.y - bullet.y;
                _bullets.push(bullet);
                pos += space;
            }
        }
    }
    
    //增加敌机
    if(time - ENEMY_STATE.foreTime >= ENEMY_STATE.interval) {
        ENEMY_STATE.foreTime = time;
        var r = parseInt(ENEMY_STATE.chance3 * Math.random());
        var enemy;
        if(r < ENEMY_STATE.chance1) {
            enemy = _clone(ENEMY1);
        } else if(r < ENEMY_STATE.chance2) {
            enemy = _clone(ENEMY2);
        } else {
            enemy = _clone(ENEMY3);
        }
        enemy.y = -enemy.img.height;
        enemy.x = parseInt(Math.random()*_canvasWidth);
        if(enemy.x + enemy.img.width >= _canvasWidth) {
            enemy.x = _canvasWidth - enemy.img.width;
        }
        _enemies.push(enemy);
    }
    
    var enemy;
    var x1 = HERO.x;
    var y1 = HERO.y + 20;
    var x2 = x1 + HERO.img.width;
    var y2 = y1 + HERO.img.height;
    
    num = _enemies.length;
    for(var i = num - 1; i >= 0; i--) { //从后往前，因为中间可能要删除
        enemy = _enemies[i];
        enemy.y += enemy.speed;
        if(time - enemy.foreTime > ENEMY_STATE.fallTime) {
            enemy.foreTime = time;
            if(enemy.state == ENEMY_BEHIT) {
                enemy.state = ENEMY_FALL;
            } if(enemy.state == ENEMY_FALL) {
                enemy.state = ENEMY_CRASH;
            }
        }
        
        if(enemy.state == ENEMY_CRASH //坠毁了
           || enemy.y >= _canvasHeight) { //或者出界了
            _enemies.splice(i, 1); //删除元素
            continue;
        }
        _impact(enemy, x1, y1, x2, y2);
    }
    
    num = _bullets.length;
    for(var i = num - 1; i >= 0; i--) {
        bullet = _bullets[i];
        bullet.y -= bullet.speed; //坐标递减
        if(bullet.y + bullet.img.height <= 0) { //出界了
            _bullets.splice(i, 1); //删除元素
            continue;
        }
        if(_shootEnemy(bullet)) {
            _bullets.splice(i, 1); //子弹已爆炸，删除
        }
    }
    
    var boom;
    num = _booms.length;
    for(var i = num - 1; i >= 0; i--) {
        boom = _booms[i]; //炸点位置不变
        if(time - boom.foreTime < ENEMY_STATE.boomTime) {
            continue;
        }
        boom.foreTime = time;
        if(boom.state == BOOM_FIRE) {
            boom.state = BOOM_BLAST;
        } else if(boom.state == BOOM_BLAST) {
            boom.state = BOOM_VANISH
        } else {
            _booms.splice(i, 1); //删除元素
        }
    }
}

const _impact = (enemy, x1, y1, x2, y2) => { //撞机
    var ex1 = enemy.x;
    var ex2 = enemy.x + enemy.img.width;
    var ey1 = enemy.y;
    var ey2 = enemy.y + enemy.img.height;
    if(ex2 < x1 || ex1 > x2 || ey1 > y2 || ey2 < y1 || enemy.life <= 0) {
        return;
    }
    if(HERO.life > 0) {
        HERO.life--;
    }
    _setResult(HERO.score, HERO.life);
    enemy.life = 0; //敌机直接撞死
    enemy.state = ENEMY_BEHIT; //敌机也会被击中
    _e3CrushVoice.play(); //撞机声音
}

//判断子弹是否射中了敌机，如果射中，返回true
const _shootEnemy = (bullet) => {
    var enemy;
    var boom;
    var shoot = false;
    var x0 = bullet.x + bullet.x0; //子弹中心点
    var y0 = bullet.y + bullet.y0;
    for(var i in _enemies) {
        enemy = _enemies[i];
        if(x0 < enemy.x || x0 >= enemy.x + enemy.img.width
           || y0 < enemy.y || y0 > enemy.y + enemy.img.height) {
            continue;
        }
        
        //添加炸点
        boom = _clone(BOOM);
        boom.x = x0 - boom.x0;
        boom.y = y0 - boom.y0;
        _booms.push(boom); 
        enemy.life--;
        HERO.score += enemy.score;
        _setResult(HERO.score, HERO.life)
        if(enemy.life == 0) {
            enemy.state = ENEMY_BEHIT; //敌机被击中
            //_e3CrushVoice.play();
        }
        shoot = true;
        break;
    }
    return shoot;
}

const _drawGame = () => { //显示游戏中的元素
    _visionY += _visionSpeed;
    if(_visionY > _canvasHeight) {
        _visionY = 0;
    }
    //先画背景，背景也是移动中的
    if(_visionY > 0) {
        _drawImage(0, _visionY-_canvasHeight, GAME_BG, _canvasWidth, _canvasHeight); 
    }
    _drawImage(0, _visionY, GAME_BG, _canvasWidth, _canvasHeight);
    
    var enemy;
    for(var i in _enemies) { //画敌机
        enemy = _enemies[i];
        if(enemy.state == ENEMY_OK) {
            _drawImage(enemy.x, enemy.y, enemy.img);
        } else {
            var ratio = (1-1/enemy.state) / 2;
            var x = enemy.x + enemy.img.width * ratio;
            var y = enemy.y + enemy.img.height * ratio;
            _drawImage(x, y, enemy.img, //缩小，模拟坠机
                enemy.img.width/enemy.state, enemy.img.height/enemy.state);
        }
    }
    
    var boom;
    for(var i in _booms) { //画炸点
        boom = _booms[i];
        _drawImage(boom.x, boom.y, boom.img, //放大，模拟炸开的烟雾
            boom.img.width*boom.state, boom.img.height*boom.state);
    }
    
    var bullet;
    for(var i in _bullets) { //画子弹
        bullet = _bullets[i];
        _drawImage(bullet.x, bullet.y, bullet.img);
    }
    
    _drawImage(HERO.x, HERO.y, HERO.img); //画英雄机
    _validate();//使画布生效
}

export default {
inject:['service', 'tags'],
mounted(){
    Platform.portrait(); //强制竖屏
    window._gameOver=this.gameOver;
    window._setResult=this.setResult;
    window._isRunning=()=>{return this.runstate==1};
    _canvas = document.getElementById("gameCanvas");
    _brush = _canvas.getContext("2d");
    _bufferedCanvas = document.createElement('canvas'); //用于缓存画的内容，避免界面闪烁
    _bufferedCanvas.width = _canvas.width;
    _bufferedCanvas.height = _canvas.height;
    _bufferedBrush = _bufferedCanvas.getContext('2d');
    
    _bulletVoice = document.getElementById('bullet');
    _bgMusic=document.getElementById('game_music');
    _gameOverMusic=document.getElementById('game_over');
    _e3CrushVoice=document.getElementById('enemy3crush');

    //移动浏览器
    _canvas.ontouchmove = (e) => {
        var t=e.touches[0];
        var x=t.clientX;
        var y=t.clientY;
        if(x >= HERO.x && x <= HERO.x+HERO.img.width
           && y >= HERO.y&& y <= HERO.y+HERO.img.height) {
            HERO.x = x - HERO.x0;
            HERO.y = y - HERO.y0;
        }
        return false;//阻止冒泡
    }
    //PC浏览器
    _canvas.onmousedown = (e) => {
        var x=e.offsetX;
        var y=e.offsetY;
        if(x >= HERO.x && x <= HERO.x + HERO.img.width && y >= HERO.y && y <= HERO.y+HERO.img.height) {
            _isMoving=true;
            HERO.x = x - HERO.x0;
            HERO.y = y - HERO.y0;
        }
        return false;
    }
    _canvas.onmousemove = (e)=>{
        if(!_isMoving) return true;
        if(!_isRunning()) return true;
        HERO.x = e.offsetX - HERO.x0;
        HERO.y = e.offsetY - HERO.y0;
        return false;
    }
    
    _canvas.onmouseup = (e) => {
        _isMoving=false;
    }
    
    //确认图片加载完成后，再开启程序
    _drawImage(0, 0, START_BG, _canvasWidth, _canvasHeight);
    _validate();
},
data(){return{
    height:_canvasHeight,
    width:_canvasWidth,
    btnWidth:_btnWidth,
    btnTop:parseInt(_canvasHeight*0.62),
    btnLeft:parseInt((_winWidth-_btnWidth)/2),
    scoreLeft:5+parseInt((_winWidth-_canvasWidth)/2),
    lifeLeft:parseInt((_winWidth + _canvasWidth)/2)-_btnWidth-5,
    runstate:0,//0:init,1:running,2:over
    timer:null,
    life:10,
    score:0,
    gameSpeed:35//游戏速度，多少毫秒处理一次
}},
methods:{
startGame() {
    _enemies.length=0; //清除所有敌人
    _booms.length=0;
    _bullets.length=0;
    
    HERO.x = (_canvasWidth - HERO.img.width) / 2;
    HERO.y = _canvasHeight - HERO.img.height;
    HERO.score=0;
    HERO.life=10;
    this.setResult(0, 10);
    _drawImage(0, 0, GAME_BG, _canvasWidth, _canvasHeight);
    _validate();
    _brush.drawImage(_bufferedCanvas, 0, 0);
    _visionY = 0;
    if(_gunNumber <= 0) { // 至少需要1把枪
        _gunNumber = 1;
    }

    this.runstate=1;
    this.timer = setInterval(_game, this.gameSpeed); //启动定时器，定时刷新
},
gameOver() { //游戏结束
    _gameOverMusic.play();
    this.stopIt();
},
stopIt() {
    this.runstate=2;
    _bgMusic.pause();
    _bulletVoice.pause();
    clearInterval(this.timer);
    this.timer=null;
},
exit() {
    this.stopIt();
    Platform.undefineOrientation(); //去除强制竖屏
    this.$router.back();
},
setResult(score,life) {
    this.score=score;
    this.life=life;
},
jumpTo(name) {
    this.$router.push('/' + name);
}
},

template: `
<q-layout view="hHh lpr fff" container style="height:100vh;" class="q-pa-none">
  <q-page-container>
    <q-page class="q-pa-none">
<q-page-sticky position="top-left">
  <q-btn flat icon="arrow_back" color="primary" @click="exit"></q-btn>
</q-page-sticky>
<q-page-sticky position="top" v-show="runstate>0">
  <q-chip color="red" text-color="amber-12" icon="military_tech" :label="score"></q-chip>
  <q-chip color="green" text-color="white" icon="bloodtype" :label="life"></q-chip>
</q-page-sticky>
<div style="border:0;padding:0;margin:0 auto;text-align:center;
    cursor:move;overflow:hidden;user-select:none;">
  <canvas id="gameCanvas" :width="width" :height="height"></canvas>
</div>
<q-page-sticky position="bottom">
  <q-btn round color="grey" icon="my_location" @click="startGame"
   size="xl" class="q-mb-xl" v-show="runstate!=1"></q-btn>
</q-page-sticky>
    </q-page>
  </q-page-container>
</q-layout>

<audio src="airbattle/audio/enemy2_out.mp3" preload id="bullet"></audio>
<audio src="airbattle/audio/enemy3_down.mp3" preload id="enemy3crush"></audio>
<audio src="airbattle/audio/game_music.mp3" preload id="game_music" loop></audio>
<audio src="airbattle/audio/game_over.mp3" preload id="game_over"></audio>
`
}