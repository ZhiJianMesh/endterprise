export default {
en:{
  restart:"Restart",
  check_result:"Check",
  app_name:"Focus",
  directory:"Sequence",
  re_read:"Re-Read",
  train_schulte:"Schulte",
  train_erase:"Number erase",
  train_hearing:"Hearing",
  airbattle:"Air Battle",
  score:"Score",
  life:"Life",
  startGame:"Start Game",
  reStartGame:"Restart Game"
},
cn:{
  restart:"重新开始",
  check_result:"检查结果",
  app_name:"专注力",
  directory:"顺序",
  re_read:"重读",
  train_schulte:"舒尔特方格",
  train_erase:"字母划消",
  train_hearing:"听觉测试", 
  airbattle:"飞机大战",
  score:"得分",
  life:"生命",
  startGame:"开始游戏",
  reStartGame:"重新开始游戏"
}
};