export default {
inject:['service', 'tags'],
methods:{
jumpTo(name) {
    this.$router.push('/' + name);
}
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;">
  <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-avatar square><img src="./favicon.png"></q-avatar>
      <q-toolbar-title>{{tags.app_name}}</q-toolbar-title>
    </q-toolbar>
  </q-header>
  <q-page-container>
    <q-page class="q-pa-md">
    
<q-list>
  <q-item clickable v-ripple @click="jumpTo('schulte')">
    <q-item-section avatar>
      <q-icon color="primary" name="grid_on"></q-icon>
    </q-item-section>

    <q-item-section>{{tags.train_schulte}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
  
  <q-item clickable v-ripple @click="jumpTo('charerase')">
    <q-item-section avatar>
      <q-icon color="primary" name="format_clear"></q-icon>
    </q-item-section>

    <q-item-section>{{tags.train_erase}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
  
  <q-item clickable v-ripple @click="jumpTo('hearing')">
    <q-item-section avatar>
      <q-icon color="primary" name="hearing"></q-icon>
    </q-item-section>

    <q-item-section>{{tags.train_hearing}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
  
  <q-item clickable v-ripple @click="jumpTo('airbattle')">
    <q-item-section avatar>
      <q-icon color="primary" name="connecting_airports"></q-icon>
    </q-item-section>

    <q-item-section>{{tags.airbattle}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
</q-list>
    </q-page>
  </q-page-container>
</q-layout>
`
}