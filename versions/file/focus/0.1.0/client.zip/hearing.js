export default {
inject:['service', 'tags'],
data() {return {
    startTime:0,
    useTime:0,
    readIdx:-1, //当前正则读的字符
    count:0,
    size:5,
    sizeOpts:[3,4,5,6,7,8,9,10],
    positiveSeq:true, //true正序，false反序
    speed:0.8,
    numbers:'',
    answer:'',
    keyTd:{
        border:'2px solid #000',
        'text-align':'center',
        'vertical-align':'middle',
        width:'',
        height:'',
        fontSize:'',
        cursor:'pointer'
    },
    answerDiv:{
        fontSize:'',
        height:'',
        'text-align':'center',
        'word-spacing':'4px',
        cursor:'pointer'
    }
}},
created(){
    this.size=parseInt(storageGet(this.service.K_HEARING_NUM_SIZE, '5'));
    var w,fs;
    if(document.body.clientWidth>window.screen.height) {
        var size=80/6;
        w=size+'vh'; fs=(size/1.5)+'vh';
    }else{
        var size=90/6;
        w=size+'vw'; fs=(size/1.5)+'vw';
    }
    this.startTime=0;
    this.answerDiv={height:w,fontSize:fs,'text-align':'center'};
    this.keyTd={width:w,height:w,fontSize:fs,cursor:'pointer','text-align':'center'};

    this.refresh_num();
},
beforeUnmount() {
    this.readIdx=this.size-1;
    this.service.player.pause();
},
watch:{
    size(nv,ov) {
        if(nv==ov) {
            return;
        }
        storageSet(this.service.K_HEARING_NUM_SIZE, nv);
        this.refresh_num();
    }
},
methods:{
    refresh_num() {
        this.answer='';
        this.numbers=new Array(this.size);
        this.numbers=String.fromCharCode(48+Math.floor(Math.random()*9)+1);//第一个不为0
        for(var i=1; i<this.size;i++) {
            this.numbers+=String.fromCharCode(48+Math.floor(Math.random()*10));
        }
        this.readIt()
    },
    touch_num(c) {
        if(this.startTime==0) {
            this.startTime=new Date().getTime();
        }
        if(c=='b') {//backspace
            if(this.answer!='') {
                this.answer=this.answer.substr(0,this.answer.length-1);
            }
        } else if(c=='v') {//re-read
            this.readIt();
        } else if(this.answer.length<this.size){
            this.answer+=c;
            if(this.answer.length<this.numbers.length) {
                return;//没有输满
            }
            var over=false;
            if(this.positiveSeq) { //正序
                over = this.answer==this.numbers;
            } else { //反序
                var s=this.numbers.split('').reverse().join('');
                over = this.answer==s;
            }
            if(over) {
                this.count++;
                this.useTime=(new Date().getTime()-this.startTime)/1000;
                this.refresh_num();
            }
        }
    },
    readIt() {
        if(this.readIdx<0) {
            this.innerRead();
        }
    },
    innerRead() {
        if(this.readIdx==this.size-1) {
            this.readIdx=-1;
        } else {
            this.readIdx++;
            var ch=this.numbers.charAt(this.readIdx);
            this.service.player.src = "/assets/sounds/"+ch+".mp3";
            this.service.player.play();
            setTimeout(this.innerRead, this.speed*1000);
        }
    }
},
template:`
<q-layout view="lHh lpr lFf" container style="height:100vh;">
  <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.train_hearing}}</q-toolbar-title>
      <q-chip color="green" text-color="white" icon="alarm" :label="useTime"></q-chip>
      <q-chip color="red" text-color="amber-12" icon="military_tech" :label="count"></q-chip>
      <q-select v-model="size" filled :options="sizeOpts" emit-value map-options dense></q-select>
    </q-toolbar>
  </q-header>

  <q-page-container>
    <q-page class="q-pa-md">
<div class="q-py-md">
</div>

<div class="q-pa-sm" v-bind:style="answerDiv">
{{answer}}
</div>

<table align='center'>
 <tr><td v-for="i in ['0','1','2','3','4','5']" v-bind:style="keyTd" @click="touch_num(i)">{{i}}</td></tr>
 <tr>
  <td v-for="i in ['6','7','8','9']" v-bind:style="keyTd" @click="touch_num(i)">{{i}}</td>
  <td v-bind:style="keyTd" @click="touch_num('b')"><q-icon name="backspace"></q-icon></td>
  <td v-bind:style="keyTd" @click="touch_num('v')"><q-icon name="volume_up"></q-icon></td>
 </tr>
</table>

<div class="q-px-none q-py-md">
<q-list dense>
  <q-item dense>
    <q-item-section avatar>
      <q-icon name="directions_run" color="primary"></q-icon>
    </q-item-section>
    <q-item-section>
      <q-slider v-model="speed" :min="0.2" :max="2.0" step="0.2" dense></q-slider>
    </q-item-section>
  </q-item>
  <q-item dense>
    <q-item-section avatar>
      <q-icon name="swap_horiz" color="primary"></q-icon>
    </q-item-section>
    <q-item-section>
      <q-toggle v-model="positiveSeq" checked-icon="arrow_forward"
        unchecked-icon="arrow_back" :label="tags.directory" left-label></q-toggle>
    </q-item-section>
  </q-item>
</q-list>
</div>
    </q-page>
  </q-page-container>
</q-layout>
`
}