export default {
inject:['service', 'tags'],
data() {return {
    startTime:0,
    useTime:0,
    eraseChar:'3',
    charOpts:['3','b','p','d','q'],
    btn_disabled:true,
    wrongNum:0,
    rightNum:0,
    totalNum:0,
    width:0,
    fontSize:0,
    score:0,
    gameOver:false,
    characters:new Array(1200),
    next_num:1
}},
created(){
    this.eraseChar=storageGet(this.service.K_ERASECHAR, '3');
    if(document.body.clientWidth>window.screen.height) {
        this.width='10vh'; this.fontSize='7vh';
    }else{
        this.width='10vw'; this.fontSize='7vw';
    }

    this.refresh_chars();
},
watch:{
    eraseChar(nv,ov) {
        if(nv==ov) {
            return;
        }
        storageSet(this.service.K_ERASECHAR, nv);
        this.refresh_chars();
    }
},
methods:{
    refresh_chars() {
        this.wrongNum=0;
        this.rightNum=0;
        this.totalNum=0;
        this.score=0;
        this.refresh_key++;
        this.btn_disabled=true;
        this.useTime=0;
        this.gameOver=false;

        var validChars;
        if(this.eraseChar=='3') {
            validChars=this.gen_chars('0-9', '3', '5');
        } else if(this.eraseChar=='p') {
            validChars=this.gen_chars('a-z', 'p', 'q');
        } else if(this.eraseChar=='q') {
            validChars=this.gen_chars('a-z', 'q', 'p');
        } else if(this.eraseChar=='b') {
            validChars=this.gen_chars('a-z', 'b', 'd');
        } else {
            validChars=this.gen_chars('a-z', 'd', 'b');
        }
        var chNum=validChars.length;
        var oneCh;
        var len=this.characters.length;

        for(var i=0;i<len;i++) {
            oneCh = validChars[Math.floor(Math.random()*chNum)];
            this.totalNum+=oneCh==this.eraseChar?1:0;
            this.characters[i]={ch:oneCh,bg:'#f000'};
        }
    },
    gen_chars(s,ch,confuse) {
        var begin=s.charCodeAt(0);
        var end=s.charCodeAt(2);
        var chars=[];
        for(var i=begin;i<=end;i++) {
            chars.push(String.fromCharCode(i));
        }
        chars.push(ch);//需要划消的多一些
        chars.push(confuse); //混淆的也要多一点
        return chars;
    },
    touch_char(i) {
        if(this.gameOver) {
            return;
        }
        var o=this.characters[i];
        if(o.ch != this.eraseChar) {
            if(o.bg=='#f00') {
                o.bg='#fdd';
                this.wrongNum--; //清除错误
            } else {
                o.bg='#f00';
                this.wrongNum++;
            }
        } else if(o.bg!='#ee0'){
            o.bg='#ee0';
            this.rightNum++;
        }
        if(this.rightNum + this.wrongNum==1) {//第一个，开始计时
            this.btn_disabled=false;
            this.startTime=new Date().getTime();
        } else {
            this.useTime=(new Date().getTime()-this.startTime)/1000;
        }
        this.score=Math.floor(100*(this.rightNum-this.wrongNum)/this.totalNum);
    },
    check_result(){
        var len=this.characters.length;
        for(var i=0;i<len;i++) {
            var o=this.characters[i];
            if(o.ch!=this.eraseChar) {
                continue;
            }
            if(o.bg=='#f000') {
                o.bg='#f00';
                this.wrongNum++;
            }
        }
        this.gameOver=true;
        this.score=Math.floor(100*(this.rightNum-this.wrongNum)/this.totalNum);
    },
    go_back() {
        service.router.back();
    }
},
template:`
<q-layout view="lHh lpr lFf" container style="height:100vh;">
  <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.train_erase}}</q-toolbar-title>
      <q-chip color="green" text-color="white" icon="alarm" :label="useTime"></q-chip>
      <q-chip color="red" text-color="amber-12" icon="military_tech" :label="score"></q-chip>
      <q-select v-model="eraseChar" label-color="white" filled :options="charOpts" emit-value map-options dense></q-select>
    </q-toolbar>
  </q-header>
  <q-page-container>
    <q-page class="q-pa-md">
<q-page-sticky position="top">
<div class="q-py-sm">
 <q-btn color="primary" :disable="btn_disabled" icon="playlist_add_check" @click="check_result" class="q-mr-md"></q-btn>
 <q-btn color="primary" :disable="btn_disabled" icon="refresh" @click="refresh_chars" class="q-ml-md"></q-btn>
</div>
</q-page-sticky>
<div v-bind:style="{height:width}"></div><!--将内容往下挪一行，给按钮留空间-->
<div class="q-pa-none">
 <div v-for="(o,i) in characters" 
  v-bind:style="{float:'left',background:o.bg,cursor:'pointer','text-align':'center',width:width,height:width,fontSize:fontSize,
  'vertical-align':'middle'}" @click="touch_char(i)">{{o.ch}}</div>
</div>
    </q-page>
  </q-page-container>
</q-layout>
`
}