export default {
inject:['service', 'tags'],
data() {return {
    startTime:0,
    useTime:0,
    btn_disabled:true,
    size:5,
    width:0,
    fontSize:0,
    sizeOpts:[{label:'5*5',value:5},{label:'6*6',value:6}],
    numbers:null,
    beep:new Audio("/assets/sounds/beep.mp3"),
    next_num:1
}},
created(){
    this.size=parseInt(storageGet(this.service.K_SCHULTE_SIZE, '5'));
    var w,fs;
    if(document.body.clientWidth>window.screen.height) {
        var size=(70/this.size);
        this.width=size+'vh'; this.fontSize=(size/2)+'vh';
    }else{
        var size=(60/this.size);
        this.width=size+'vw'; this.fontSize=(size/2)+'vw';
    }
    this.refresh_num();
},
watch:{
    size(nv,ov) {
        if(nv==ov) {
            return;
        }
        storageSet(this.service.K_SCHULTE_SIZE, nv);
        this.refresh_num();
    }
},
methods:{
    refresh_num() {
        this.next_num=1;
        this.btn_disabled=true;
        this.useTime=0;

        var numbers=new Array(len);
        var len=this.size*this.size;
        for(var i=0; i<len;i++) { //clear at first
            numbers[i]=0;
        }
        for(var i=0; i<len;i++) { //保证位置随机且唯一
            var n=Math.floor(Math.random()*(len-i));
            for(var j=0,k=0;j<len;j++) {
                if(numbers[j]===0){
                    if(k===n) {
                        numbers[j]=i+1;
                        break;
                    }
                    k++;
                }
            }
        }
        this.numbers=new Array(this.size); //二维化
        var offset=0;
        for(var i=0;i<this.size;i++) {
            var row=new Array(this.size);
            for(var j=0;j<this.size;j++) {
                row[j]={ch:numbers[offset+j],bg:'#f000'};
            }
            this.numbers[i]=row;
            offset+=this.size;
        }
    },
    touch_num(i,j) {
        if(this.next_num != this.numbers[i][j].ch) {
            this.beep.play();
            return;
        }
        this.numbers[i][j].bg="#ee0";
        if(this.next_num==1) {
            this.btn_disabled=false;
            this.startTime=new Date().getTime();
        }
        this.next_num++;
        this.useTime=(new Date().getTime()-this.startTime)/1000;
    }
},
template:`
<q-layout view="lHh lpr lFf" container style="height:100vh;">
  <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.train_schulte}}</q-toolbar-title>
      <q-chip color="green" text-color="white" icon="alarm" :label="useTime"></q-chip>
      <q-select v-model="size" filled :options="sizeOpts" emit-value map-options dense></q-select>
    </q-toolbar>
  </q-header>

  <q-page-container>
    <q-page class="q-pa-md">
<q-page-sticky position="bottom">
 <q-btn class="q-mb-md" color="primary" :disable="btn_disabled"
  icon="refresh" @click="refresh_num" :label="tags.restart"></q-btn>
</q-page-sticky>
<table align="center">
 <tr v-for="(row,i) in numbers">
  <td v-for="(o,j) in row" :style="{border:'2px solid #000','cursor':'pointer','text-align':'center','vertical-align':'middle',
  width:width,height:width,fontSize:fontSize,background:o.bg}" @click="touch_num(i,j)">{{o.ch}}</td>
 </tr>
</table>
    </q-page>
  </q-page-container>
</q-layout>
`
}