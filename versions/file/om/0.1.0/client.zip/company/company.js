const SERVICE="company";
const EMPTY_COMPANY={creditCode:"",name:"",pwd:"",info:"",partition:250000,dlg:false}
export default {
inject:['service', 'tags'],
data() {return {
    companies:[],
    newCompany:{},
    page:{cur:1, max:0},
    search:''
}},
created(){
    this.newCompany=cloneObj(EMPTY_COMPANY);
    this.query_companies(1);
},
methods:{
company_detail(id) {
    this.service.go_to('/company/detail?id='+id);
},
query_companies(pg) {
    var offset=(parseInt(pg)-1)*+this.service.N_PAGE;
    var url="/company/list?offset="+offset+"&num="+this.service.N_PAGE;
    this.service.request_om({method:"GET",url:url},SERVICE).then(resp =>{
        if(resp.code != RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.page.max=Math.ceil(resp.data.total/this.service.N_PAGE);
        this.companies=resp.data.companies;
    });
},
search_companies() {
    var url="/company/search?limit="+this.service.N_PAGE+"&s="+this.search;
    this.service.request_om({method:"GET",url:url},SERVICE).then(resp =>{
        if(resp.code != RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.page.max=1;
        this.companies=resp.data.companies;
    });
},
create_company() {
    var c=this.newCompany;
    var dta={creditCode:c.creditCode,name:c.name,info:c.info,
        pwd:c.pwd,partition:c.partition};
    this.service.request_om({method:"POST",url:"/company/omregister",data:dta}, SERVICE).then(resp => {
        if(resp.code != 0) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.query_companies(this.page.cur);
        this.newCompany=cloneObj(EMPTY_COMPANY);
    })
},
chkCredit(code) {//不能在rules中直接调用原生对象的函数，原因未知
    return JStr.chkCreditCode(code);
}
},
    
template: `
<q-layout view="hHh lpr fFf" container style="height:100vh">
 <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.tab_company}}</q-toolbar-title>
    </q-toolbar>
 </q-header>
 <q-footer class="bg-white q-px-md q-pt-md">
   <q-input outlined bottom-slots v-model="search" :label="tags.search" dense @keyup.enter="search_companies">
     <template v-slot:append>
      <q-icon v-if="search!==''" name="close" @click="query_companies(1)" class="cursor-pointer"></q-icon>
      <q-icon name="search" @click="search_companies"></q-icon>
     </template>
     <template v-slot:after>
      <q-btn round color="primary" icon="add_circle" @click="newCompany.dlg=true"></q-btn>
     </template>
   </q-input>
 </q-footer>
 <q-footer class="bg-white q-px-md q-pt-md">
 </q-footer>
 <q-page-container>
    <q-page class="q-pa-md">
<div class="q-pa-sm flex flex-center" v-if="page.max>1">
 <q-pagination v-model="page.cur" color="primary" :max="page.max" max-pages="10"
  boundary-numbers="false" @update:model-value="query_companies"></q-pagination>
</div>
<q-list separator>
  <q-item clickable v-for="c in companies" @click="company_detail(c.id)">
    <q-item-section>{{c.id}}</q-item-section>
    <q-item-section>{{c.name}}</q-item-section>
    <q-item-section>{{c.creditCode}}</q-item-section>
    <q-item-section>{{c.province}}/{{c.city}}</q-item-section>
  </q-item>
</q-list>
    </q-page>
  </q-page-container>
</q-layout>

<component-alert-dialog ref="errDlg" :title="tags.failToCall" :close="tags.close"></component-alert-dialog>

<q-dialog v-model="newCompany.dlg">
 <q-card style="min-width:70vw">
  <q-card-section>
   <div class="text-h6">{{tags.createCompany}}</div>
  </q-card-section>
  <q-card-section class="q-pt-none">
   <q-list>
    <q-item><q-item-section>
     <q-input v-model="newCompany.partition" label="Partition ID" dense 
      :rules="[v=>v>=0|| 'Please input number >= 0']"></q-input>
    </q-item-section></q-item>
    
    <q-item><q-item-section>
     <q-input v-model="newCompany.creditCode" maxlength=18
      label="Unified credit code" dense
     :rules="[v=>chkCredit(v)||tags.taxidPls]"></q-input>
    </q-item-section></q-item>
    <q-item><q-item-section>
     <q-input v-model="newCompany.name" label="Name" dense
     :rules="[v=>v.length<100 || 'Please input 1-100 characters']"></q-input>
    </q-item-section></q-item>
    <q-item><q-item-section>
     <q-input v-model="newCompany.pwd" label="Password" dense></q-input>
    </q-item-section></q-item>
    <q-item><q-item-section>
     <q-input v-model="newCompany.info" label="Information" dense></q-input>
    </q-item-section></q-item>
   </q-list>
 </q-card-section>
  <q-card-actions align="right">
    <q-btn :label="tags.ok" color="primary" @click="create_company"></q-btn>
    <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
  </q-card-actions>
 </q-card>
</q-dialog>
`}