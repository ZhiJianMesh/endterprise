const SERVICE="company";
const FOR_EVER=253202544000000;
const EMPTY_SERVICE={dlg:false,service:'',validAt:0,expiresAt:FOR_EVER,balance:0,range:'',isEdit:false};
const S_BACKUP='backup';
const DAY_MS=86400000;

export default {
inject:['service', 'tags'],
data() {return {
    id:this.$route.query.id,
    services:[],
    company:{name:"",info:"",partition:"",authKey:"",address:{}},
    httpdns:{outsideAddr:'',insideAddr:'',accessCode:''},
    serviceInfo:{},
    page:{cur:1, max:0},
	stats:{dlg:false,chart:null,width:0,date:{from:'',to:''},proxyDate:{from:'',to:''}},
    companyOpts:[] //已有公司级服务列表
}},
created(){
	var dt=new Date();
	var to=dt.getFullYear()+'/'+(dt.getMonth()+1)+'/'+dt.getDate();
	dt.setTime(dt.getTime()-3*DAY_MS);
	var from=dt.getFullYear()+'/'+(dt.getMonth()+1)+'/'+dt.getDate();
	this.stats.date={from:from,to:to};
	this.stats.width=document.documentElement.clientWidth*0.7;
    this.serviceInfo=cloneObj(EMPTY_SERVICE);
    this.query_info();
    this.query_httpdns();
    this.query_services(1);
    this.service.companyServices().then(list=>{
        var opts=[];
        opts.push({label:S_BACKUP, value:S_BACKUP});
        for(var s of list) {
            opts.push({label:s.displayName+'('+s.service+')', value:s.service});
        }
        this.companyOpts=opts;
    })
},
methods:{
query_info() {
    var url="/company/detail?id=" + this.id;
    this.service.request_om({method:"GET",url:url}, SERVICE).then(resp => {
        if(!resp || resp.code != RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.company=resp.data;
        this.company.address={
            province:resp.data.province,
            city:resp.data.city,
            county:resp.data.county
        };
    });
},
query_httpdns() {
    var url="/company/omget?cid=" + this.id;
    this.service.request_om({method:"GET", url:url}, "httpdns").then(resp => {
        if(resp.code != RetCode.OK) {
            if(resp.code != RetCode.NOT_EXISTS) {
                this.$refs.errDlg.showErr(resp.code, resp.info);
            }
            return;
        }
        this.httpdns=resp.data;
        this.httpdns.accessCode='';
    });
},
query_services(pg) {
    var offset=(parseInt(pg)-1) * this.service.N_PAGE;
    var url="/service/openedServices?cid="+this.id+"&offset="+offset+"&num="+this.service.N_PAGE;
    this.service.request_om({method:"GET",url:url}, SERVICE).then(resp=>{
        var services=[];
        var flag=0;
        if(resp.code != RetCode.OK) {
            this.page.max=0;
            this.page.cur=1;
            this.services=[];
            if(resp.code != RetCode.NOT_EXISTS) {
                this.$refs.errDlg.showErr(resp.code, resp.info);
            }
        } else {
            this.page.max=Math.ceil(resp.data.total/this.service.N_PAGE);
            var d=new Date();
            var cols=resp.data.cols;
            for(var l of resp.data.list) {
                var o={};
                for(var i in cols) {
                    o[cols[i]]=l[i];
                }
                var validAt, expiresAt;
                if(o.validAt<=0) {
                    validAt='Now';
                } else {
                    d.setTime(o.validAt);
                    validAt=d.toLocaleDateString();
                }
                if(o.expiresAt>=FOR_EVER) {
                    expiresAt='For ever';
                } else if(o.expiresAt<=0) {
                    expiresAt='Invalid';
                } else {
                    d.setTime(o.expiresAt);
                    expiresAt=d.toLocaleDateString();
                }
                if(o.service==S_BACKUP) {
                    flag+=2;
                    o.ext='-';
                }
                o.range=validAt+'->'+expiresAt;
                services.push(o);
            }
        }
        if((flag&2)==0) {
            services.push({service:S_BACKUP,validAt:0,expiresAt:FOR_EVER,
                balance:0,range:"Now->For ever",ext:'-'});
        }
        this.services = services;
    })
},
remove_company() {
    if(this.services.length>0) {
        this.$refs.errDlg.showErr(RetCode.EXISTS, "There are already acl settings");
        return;
    }
    var url="/company/remove?id=" + this.id;
    this.service.request_om({method:"DELETE", url:url}, "company").then(resp => {
        if(!resp || resp.code != 0) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        if(resp.data.aclNum>0) {
            this.$refs.errDlg.showErr(RetCode.EXISTS, "There are already acl settings");
            return;
        }
        this.service.go_back();
    })
},
show_edit(i) {
    var s=this.services[i];
    this.serviceInfo={dlg:true,isEdit:true,service:s.service,
        validAt:s.validAt,expiresAt:s.expiresAt,balance:s.balance,
        range:s.range}
},
set_service() {
    var si=this.serviceInfo;
    var dta={cid:this.id, service:si.service,validAt:si.validAt,
         expiresAt:si.expiresAt, val:si.balance};
    this.service.request_om({method:"PUT", url:"/service/recharge", data:dta}, SERVICE).then(resp => {
        if(resp.code != 0) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.serviceInfo=cloneObj(EMPTY_SERVICE);
        this.query_services(this.page.cur);
    })
},
init_service(i) {
    var service=this.services[i].service;
    var url="/initialize?cid="+this.id;
    this.service.request_om({method:"GET", url:url, headers:{cid:this.id}}, service).then(resp => {
		if(resp.code != RetCode.OK) {
			this.$refs.errDlg.showErr(resp.code, resp.info);
			return;
		}
        this.services[i].ext=resp.data.dbs;
        var dta={cid:this.id,service:service,ext:resp.data.dbs};
        this.service.request_om({method:"PUT", url:"/service/setinfo", data:dta}, SERVICE).then(resp1 => {
            if(resp1.code != RetCode.OK) {
			    this.$refs.errDlg.showErr(resp1.code, resp1.info);
			} else {
                this.$refs.errDlg.show(this.tags.oprSuccess);
            }
        });
    })
},
disable_service(s) {
    var url="/service/remove?cid="+this.id+"&service="+this.serviceInfo.service;
    this.service.request_om({method:"DELETE",url:url}, SERVICE).then(resp => {
        if(resp.code != RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.query_services(this.page.cur);
    })
},
update_company(){
    var c=this.company;
    var dta={id:this.id, name:c.name, creditCode:c.creditCode, info:c.info, authKey:c.authKey,
        province:c.address.province, city:c.address.city, county:c.address.county, dbNo:c.dbNo};
    this.service.request_om({method:"PUT", url:"/company/omSetInfo", data:dta}, SERVICE).then(resp=>{
        if(!resp || resp.code != 0) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
    });
},
update_httpdns(){
    var h=this.httpdns;
    var dta={cid:this.id, expiresAt:253202544000000,
        outsideAddr:h.outsideAddr, insideAddr:h.insideAddr};
    this.service.request_om({method:"PUT", url:"/company/omsetgw", data:dta}, "httpdns").then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
        } else if(h.accessCode) {
            var req={cid:this.id, accessCode:Secure.sha256(h.accessCode)}
            this.service.request_om({method:"PUT", url:"/company/omsetaccesscode", data:req}, "httpdns").then(r=>{
                if(r.code != RetCode.OK) {
                    this.$refs.errDlg.showErr(r.code, r.info);
                }
            });
        }
    });    
},

date_range_end(range) {
    var f=range.from;
    var t=range.to;
    this.serviceInfo.range=f.year+'/'+f.month+'/'+f.day
        +'->'+t.year+'/'+t.month+'/'+t.day;
    this.serviceInfo.validAt=new Date(f.year,f.month-1,f.day).valueOf();
    this.serviceInfo.expiresAt=new Date(t.year,t.month-1,t.day).valueOf();
},
chkLanAddr(addr) {
    if(!this.validAddr(addr)) {
        return false;
    }
    return JStr.isLanIP(addr);
},
validAddr(addr) {
    var pos=addr.lastIndexOf(':');
    if(pos<0) {
        return false;
    }
    var port=parseInt(addr.substring(pos+1));
    if(port<1000||port>65535) {
        return false;
    }
    var ip=addr.substring(0, pos);
    return JStr.isIPv4(ip)||JStr.isIPv6(ip);
},
showStats(){
	this.stats.dlg=true;
	this.stats.chart=Vue.markRaw(echarts.init(document.getElementById('stats_chart')));
    var from=parseInt(new Date(this.stats.date.from).getTime()/DAY_MS)
	var to=parseInt(new Date(this.stats.date.to).getTime()/DAY_MS)
	var opts={method:"GET", url:"/stats/companyStats?cid="+this.id+"&from="+from+"&to="+to};
    this.service.request_om(opts, "appstore").then(resp=>{
		if(resp.code != RetCode.OK) {
			this.$refs.errDlg.showErr(resp.code, resp.info);
			return;
		}
		if(resp.data.stats.length==0) {
			return;
		}
		var dt=new Date();
		var cols=resp.data.cols;
		var cn=cols.length;
		var data=[];
		
		for(var l of resp.data.stats) {
			var d={};
			for(var i=0; i<cn; i++) {
				d[cols[i]]=l[i];
			}
			data.push(d);
		}
		var xAxis=[];
		var apis=[];
		var fails=[];
		var excs=[];
		var n,t,h,oldDay=data[0].day;
		for(var l of data) {
			n=l.day-oldDay;
			if(n>1) {
				n=(n-1)*24;
				for(var i=0;i<n;i++,t+=3600000) {
					dt.setTime(t);
					apis.push(0);
					fails.push(0);
					excs.push(0);
					h=dt.getHours();
					if(h==0) {
						xAxis.push(dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate());
					}else{
						xAxis.push(h+':00');
					}
				}					
			}
			t=l.day*DAY_MS;
			for(var i=0;i<24;i++,t+=3600000) {
				dt.setTime(t);
				apis.push(l['h'+i]);
				h=dt.getHours();
				if(h==0) {
					xAxis.push(dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate());
					fails.push(l.fail);
					excs.push(l.exc);
				}else{
					xAxis.push(h+':00');
					fails.push(0);
					excs.push(0);
				}
			}
			oldDay=l.day;
		}
		var series=[
			{name:this.tags.service.requests, type:'bar', data:apis, yAxisIndex:0},
			{name:this.tags.service.fails, type:'line', data:fails, yAxisIndex:0, itemStyle:{color:'orange'}},
			{name:this.tags.service.excs, type:'line', data:excs, yAxisIndex:0, itemStyle:{color:'red'}}
		];
		
		this.stats.chart.setOption({
			title: {show:false},
			tooltip: {},
			legend: {type:'scroll', bottom:10, width:this.stats.width},
			grid: {left:'0%', containLabel:true},
			xAxis: {data:xAxis, type:'category', axisLabel:{interval:(i,l)=>{return l.length>5}}},
			yAxis: [{name:this.tags.service.unit, minInterval:1}],
			series: series
		});
	});
},
statsDateChanged() {
	if(this.stats.proxyDate) {
		this.stats.date=this.stats.proxyDate;
		this.showStats();
	}
}
},
template:`
<q-layout view="hHh lpr fFf" container style="height:100vh">
 <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{company.name}}{{tags.detailInfo}}</q-toolbar-title>
	  <q-btn flat round icon="bar_chart" dense @click="stats.dlg=true"></q-btn>
    </q-toolbar>
 </q-header>

  <q-page-container>
    <q-page class="q-pa-sm">
<q-banner rounded class="bg-grey-3 text-h5" dense>
{{tags.baseInfo}}({{this.id}})</q-banner>
<q-list dense>
 <q-item>
   <q-item-section>{{tags.company.name}}</q-item-section>
   <q-item-section>{{company.name}}
     <q-popup-edit v-model="company.name" auto-save v-slot="scope"
      :title="tags.company.name" @update:model-value="update_company"
      buttons :label-set="tags.ok" :label-cancel="tags.cancel">
      <q-input v-model="scope.value" dense autofocus @keyup.enter="scope.set"></q-input>
     </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.creditCode}}</q-item-section>
   <q-item-section>{{company.creditCode}}
     <q-popup-edit v-model="company.creditCode" auto-save v-slot="scope"
      :title="tags.company.creditCode" @update:model-value="update_company"
      buttons :label-set="tags.ok" :label-cancel="tags.cancel">
      <q-input v-model="scope.value" dense autofocus @keyup.enter="scope.set" maxlength=18></q-input>
     </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.info}}</q-item-section>
   <q-item-section style="word-break:break-all">{{company.info}}
     <q-popup-edit v-model="company.info" auto-save v-slot="scope"
      :title="tags.company.info" @update:model-value="update_company"
      buttons :label-set="tags.ok" :label-cancel="tags.cancel">
      <q-input v-model="scope.value" dense autofocus @keyup.enter="scope.set" maxlength=18></q-input>
     </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.authKey}}</q-item-section>
   <q-item-section>{{company.authKey}}
     <q-popup-edit v-model="company.authKey" auto-save v-slot="scope"
      :title="tags.company.authKey" @update:model-value="update_company"
      buttons :label-set="tags.ok" :label-cancel="tags.cancel">
      <q-input v-model="scope.value" dense autofocus @keyup.enter="scope.set"></q-input>
     </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.partition}}</q-item-section>
   <q-item-section>{{company.partition}}
     <q-popup-edit v-model="company.partition" auto-save v-slot="scope"
      :title="tags.company.partition" @update:model-value="update_company"
      buttons :label-set="tags.ok" :label-cancel="tags.cancel">
      <q-input type="number" v-model.number="scope.value" dense autofocus @keyup.enter="scope.set"></q-input>
     </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.area}}</q-item-section>
   <q-item-section>{{company.area}}
     <q-popup-edit v-model="company.area" auto-save v-slot="scope"
      :title="tags.company.area" @update:model-value="update_company"
      buttons :label-set="tags.ok" :label-cancel="tags.cancel">
      <q-input type="number" v-model.number="scope.value" dense autofocus @keyup.enter="scope.set"></q-input>
     </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.dbNo}}</q-item-section>
   <q-item-section>{{company.dbNo}}
   <q-popup-edit auto-save v-slot="scope" :title="tags.company.dbNo"
    buttons :label-set="tags.ok" :label-cancel="tags.cancel"
    v-model="company.dbNo" @update:model-value="update_company">
      <q-input type="number" v-model.number="scope.value" dense autofocus @keyup.enter="scope.set"></q-input>
   </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.address}}</q-item-section>
   <q-item-section>
    {{company.address.province}}/{{company.address.city}}/{{company.address.county}}
   <q-popup-edit auto-save v-slot="scope" :title="tags.company.address"
      buttons :label-set="tags.ok" :label-cancel="tags.cancel">
    <component-addr-input v-model="company.address" @update:model-value="update_company"></component-addr-input>
   </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.insideAddr}}</q-item-section>
   <q-item-section>{{httpdns.insideAddr}}
   <q-popup-edit auto-save v-slot="scope" :title="tags.company.insideAddr"
    buttons :label-set="tags.ok" :label-cancel="tags.cancel"
    v-model="httpdns.insideAddr" @update:model-value="update_httpdns">
    <q-input v-model="scope.value" dense autofocus @keyup.enter="scope.set"
    :rules="[v=>chkLanAddr(v)||tags.invalidAddr]"></q-input>
   </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.outsideAddr}}</q-item-section>
   <q-item-section>{{httpdns.outsideAddr}}
   <q-popup-edit auto-save v-slot="scope" :title="tags.company.outsideAddr"
    buttons :label-set="tags.ok" :label-cancel="tags.cancel"
    v-model="httpdns.outsideAddr" @update:model-value="update_httpdns">
    <q-input v-model="scope.value" dense autofocus @keyup.enter="scope.set"
    :rules="[v=>validAddr(v)||tags.invalidAddr]"></q-input>
   </q-popup-edit>
   </q-item-section>
 </q-item>
 <q-item>
   <q-item-section>{{tags.company.accessCode}}</q-item-section>
   <q-item-section>{{httpdns.accessCode}}
   <q-popup-edit auto-save v-slot="scope" :title="tags.company.accessCode"
    buttons :label-set="tags.ok" :label-cancel="tags.cancel"
    v-model="httpdns.accessCode" @update:model-value="update_httpdns">
    <q-input v-model="scope.value" dense autofocus @keyup.enter="scope.set" maxlength=10></q-input>
   </q-popup-edit>
   </q-item-section>
 </q-item>
</q-list>

<q-banner rounded inline-actions class="bg-grey-3 text-h5 q-mt-lg" dense>
{{tags.company.service}}
<template v-slot:action>
 <q-icon name="add_circle" color="primary" @click.stop="serviceInfo.dlg=true"></q-icon>
</template>
</q-banner>
<div class="q-pa-sm flex flex-center" v-if="page.max>1">
 <q-pagination v-model="page.cur" color="primary" :max="page.max" max-pages="10"
  boundary-numbers="false" @update:model-value="query_services"></q-pagination>
</div>
<q-markup-table dense flat>
 <thead><tr>
    <th>{{tags.service.name}}</th>
    <th>{{tags.service.range}}</th>
    <th>{{tags.service.balance}}</th>
    <th></th>
    <th></th>
    <th></th>
 </tr></thead>
 <tbody>
  <tr v-for="(s,i) in services">
    <td>{{s.service}}</td>
    <td>{{s.range}}</td>
    <td>{{s.balance}}</td>
    <td style="word-break:break-all">{{s.ext}}</td>
    <td>
     <q-btn :label="s.ext==''?tags.service.init:tags.service.refresh"
      v-if="s.ext!='-'" @click="init_service(i)" flat color="primary"></q-btn>
    </td>
    <td>
     <q-btn :label="tags.modify" @click="show_edit(i)" flat color="primary"></q-btn>
    </td>	
  </tr>	
 </tbody>
</q-markup-table>
    </q-page>
  </q-page-container>
</q-layout>

<component-alert-dialog ref="errDlg" :title="tags.failToCall"
 :close="tags.close"></component-alert-dialog>

<!-- 添加或修改服务弹窗 -->
<q-dialog v-model="serviceInfo.dlg" no-backdrop-dismiss>
  <q-card style="min-width:70vw">
    <q-card-section>
      <div class="text-h6">{{tags.openService}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
    <q-list>
      <q-item><q-item-section>
       <q-select v-model="serviceInfo.service" emit-value map-options
        :options="companyOpts" dense :disable="serviceInfo.isEdit"></q-select>
      </q-item-section></q-item>
      <q-item><q-item-section>
       <q-input v-model="serviceInfo.range">
        <template v-slot:append>
        <q-icon name="event" class="cursor-pointer">
          <q-popup-proxy transition-show="scale" transition-hide="scale">
            <q-date v-model="serviceInfo.range" range @range-end="date_range_end">
              <div class="row items-center justify-end">
                <q-btn v-close-popup label="Close" color="primary" flat></q-btn>
              </div>
            </q-date>
          </q-popup-proxy>
        </q-icon>
       </template>
      </q-input>
     </q-item-section></q-item>
     <q-item><q-item-section>
      <q-input v-model="serviceInfo.balance" label="Balance" dense></q-input>
     </q-item-section></q-item>
    </q-list>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn :label="tags.ok" color="primary" @click="set_service"></q-btn>
      <q-btn flat :label="tags.service.disable" color="red" v-close-popup
       @click="disable_service(serviceInfo.service)" v-if="serviceInfo.isEdit"></q-btn>
      <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>

<!-- 请求统计弹窗 -->
<q-dialog v-model="stats.dlg" no-backdrop-dismiss @show="showStats">
  <q-card style="min-width:80vw;">
    <q-card-section class="row items-center q-pb-none">
      <div class="text-h6">{{tags.service.requests}}</div>
	  <q-space></q-space>
	  <q-btn icon="event" flat>
        <q-popup-proxy cover transition-show="scale" transition-hide="scale">
          <q-date v-model="stats.proxyDate" range>
            <div class="row items-center justify-end">
              <q-btn :label="tags.ok" color="primary" @click="statsDateChanged" v-close-popup></q-btn>
              <q-btn :label="tags.close" color="primary" flat v-close-popup></q-btn>
            </div>
          </q-date>
        </q-popup-proxy>
		{{stats.date.from}} => {{stats.date.to}}
	  </q-btn>
	  <q-space></q-space>
      <q-btn icon="close" flat round dense v-close-popup></q-btn>
    </q-card-section>
    <q-card-section class="q-pt-none">
	 <div id="stats_chart" style="width:78vw;height:70vh;"></div>
    </q-card-section>
  </q-card>
</q-dialog>
`}