const SERVICE="om";
export default {
inject:['service', 'tags'],
data() {return {
    users:[],
    page:{cur:1, max:0},
    search:'',
    newUser:{service:[],account:'',power:''}
}},
created() {
    this.list(1);
},
methods:{
list(pg) {
    var offset=(this.page.cur-1)*this.service.N_PAGE;
    var url="/user/list?offset="+offset+"&num="+this.service.N_PAGE;
    this.service.request_om({method:"GET",url:url}, SERVICE).then(resp=>{
        if(resp.code != RetCode.OK) {
            console.warn("request failed:" + resp.code + ",info:" + resp.info);
            this.page.max=0;
            this.users=[];
            return;
        }
        this.page.max=Math.ceil(resp.data.total/this.service.N_PAGE);
        this.users=resp.data.list;
    })
},
search_user() {
    var url="/user/search?s="+this.search;
    this.service.request_om({method:"GET",url:url}, SERVICE).then(resp=>{
        if(resp.code != RetCode.OK) {
            console.warn("request failed:" + resp.code + ",info:" + resp.info);
            this.page.max=0;
            this.users=[];
            return;
        }
        this.page.max=Math.ceil(resp.data.total/this.service.N_PAGE);
        this.users=resp.data.list;
    })
},
add() {
    var opts={method:"POST", url:"/user/set",
      data:{service:this.newUser.service[0], account:this.newUser.account, power:this.newUser.power}};
    this.service.request_om(opts, SERVICE).then(resp => {
        if(resp.code!=RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.newUser.service=[];
        this.newUser.account='';
        this.newUser.power='';
        this.$refs.dlg_add_user.hide();
        this.list(1);
    });
},
remove(account,service,i) {
    var opts={method:"DELETE", url:"/user/rmv?account="+account+"&service="+service};
    this.service.request_om(opts, SERVICE).then(resp => {
        if(resp.code!=RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.users.splice(i,1);
    });
}
},
template:`
<q-layout view="hHh lpr fFf" container style="height:100vh">
<q-header class="bg-grey-1 text-primary">
 <q-toolbar>
  <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
  <q-toolbar-title>{{tags.om.devSet}}</q-toolbar-title>
 </q-toolbar>
</q-header>
<q-footer class="bg-white q-px-md q-pt-md">
  <q-input v-model="search" :placeholder="tags.search" dense @keyup.enter="search_service" outlined bottom-slots>
   <template v-slot:append>
    <q-icon v-if="search!==''" name="close" @click="search='';list(1)" class="cursor-pointer"></q-icon>
    <q-icon name="search" @click="search_user"></q-icon>
   </template>
   <template v-slot:after>
    <q-btn round color="primary" icon="add_circle">
	 <q-popup-proxy ref="dlg_add_user">
     <q-card>
      <q-card-section>
       <q-input v-model="newUser.account" :placeholder="tags.om.account"></q-input>
	   <component-service-selector :label="tags.om.service" :services="newUser.service" :multi="false" :useid="false"></component-service-selector>
       <q-input v-model="newUser.power" :placeholder="tags.om.power"></q-input>
      </q-card-section>
      <q-card-section align="right">
       <q-btn :label="tags.ok" color="primary" @click="add"></q-btn>
       <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
      </q-card-section>
     </q-card>
     </q-popup-proxy>
	</q-btn>
   </template>
  </q-input>
</q-footer>
<q-page-container>
  <q-page class="q-pa-md">
<q-list separator>
  <q-item>
    <q-item-section>{{tags.om.account}}</q-item-section>
    <q-item-section>{{tags.om.service}}</q-item-section>
    <q-item-section>{{tags.om.power}}</q-item-section>
  </q-item>
  <q-item v-for="(u,i) in users">
    <q-item-section>{{u.account}}</q-item-section>
    <q-item-section>{{u.service}}</q-item-section>
    <q-item-section>{{u.power}}</q-item-section>
	<q-menu touch-position context-menu v-if="u.account!='admin'">
 	 <q-list dense>
	  <q-item clickable v-close-popup @click="remove(u.account,u.service,i)">
	   <q-item-section>{{tags.remove}}</q-item-section>
	   <q-item-section avatar><q-icon name="cancel" color="red"></q-icon></q-item-section>
	  </q-item>
	 </q-list>
	</q-menu>
  </q-item>
</q-list>
  </q-page>
</q-page-container>
</q-layout>
<component-alert-dialog :title="tags.failToCall" :close="tags.close" ref="errDlg"></component-alert-dialog>
`
}