export default {
inject:['service', 'tags'],
data() {return {
	nodes:[],
	page:{cur:1, max:0},
	partId:0
}},
created() {
    this.fetch_dbs(1);
},
methods:{
fetch_dbs(pg) {
    var offset=(this.page.cur-1)*this.service.N_PAGE;
    var url="/status/dblist?offset="+offset
        +"&num="+this.service.N_PAGE+"&partId="+this.partId;
    this.service.request_om({method:"GET",url:url}, "bios").then(resp=>{
        if(resp.code != RetCode.OK) {
            console.warn("request failed:" + resp.code + ",info:" + resp.info);
			this.page.max=0;
			this.nodes=[];
            return;
        }
		this.page.max=Math.ceil(resp.data.total/this.service.N_PAGE);
        this.nodes=resp.data.list;
    })
}
},
template:`
<q-layout view="hHh lpr fFf" container style="height:100vh">
  <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
	  <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.om.srvNodes}}</q-toolbar-title>
	  <q-input v-model="partId" :label="tags.om.partId" dense outline round @keyup.enter="fetch_dbs(1)">
	   <template v-slot:append>
		<q-icon name="search" @click="fetch_dbs(1)"></q-icon>
	   </template>
	  </q-input>
    </q-toolbar>
  </q-header>

  <q-page-container>
    <q-page class="q-pa-md">
<div class="q-pa-sm flex flex-center" v-if="page.max>1">
 <q-pagination v-model="page.cur" color="primary" :max="page.max" max-pages="10"
  boundary-numbers="false" @update:model-value="fetch_dbs"></q-pagination>
</div>
<q-list separator>
  <q-item>
    <q-item-section>{{tags.om.instance}}</q-item-section>
    <q-item-section>{{tags.om.addr}}</q-item-section>
    <q-item-section>{{tags.om.status}}</q-item-section>
    <q-item-section>{{tags.om.sharding}}</q-item-section>
  </q-item>
  <q-item v-for="n in nodes">
    <q-item-section>
	 <q-item-label>{{tags.om.dbNo}}:{{n.dbNo}}</q-item-label>
	 <q-item-label caption>{{tags.om.partId}}:{{n.partId}}</q-item-label>
	 <q-item-label caption>{{tags.om.ver}}:{{n.ver}}</q-item-label>
	</q-item-section>
    <q-item-section>
	 <q-item-label>{{n.addr}}</q-item-label>
	 <q-item-label caption>{{tags.om.level}}:{{n.level}}</q-item-label>
	 <q-item-label caption>{{tags.om.slaves}}:{{n.slaves}}</q-item-label>
	</q-item-section>
    <q-item-section>{{n.status}}</q-item-section>
    <q-item-section>{{n.shardStart}}-{{n.shardEnd}}</q-item-section>
  </q-item>
</q-list>
	</q-page>
  </q-page-container>
</q-layout>
`
}