const SERVICE="appstore";
export default {
inject:['service', 'tags'],
data(){return {
    newCdn:{url:'', service:[], area:-1},
    cdns:[]
}},
created() {
    this.query_cdns();
},
methods:{
query_cdns() {
    this.service.request_om({method:"GET",url:"/cdn/omlist"}, SERVICE).then(resp => {
        if(!resp || resp.code != RetCode.OK) {
            console.warn("error:" + resp.code +",info:" + resp.info);
            return;
        }
        this.cdns=resp.data.cdns;
    })
},
add() {
    var opts={method:"POST", url:"/cdn/add",
      data:{service:this.newCdn.service[0], area:this.newCdn.area, url:this.newCdn.url}};
    this.service.request_om(opts, SERVICE).then(resp => {
        if(resp.code!=RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.newCdn.url='';
		this.$refs.dlg_add_cdn.hide();
		this.query_cdns();
    });
},
remove(id,i) {
    var opts={method:"DELETE", url:"/cdn/rmv?id="+id};
    this.service.request_om(opts, SERVICE).then(resp => {
        if(resp.code!=RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.cdns.splice(i,1);
    });
}
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;">
 <q-header class="bg-grey-1 text-primary">
  <q-toolbar>
   <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
   <q-toolbar-title>{{tags.om.cdnSet}}</q-toolbar-title>
	<q-btn text-color="primary" icon="add_circle" flat dense>
	 <q-popup-proxy ref="dlg_add_cdn">
	  <q-card>
	   <q-card-section>
	    <component-service-selector :label="tags.om.service" :services="newCdn.service" :multi="false" :useid="false"></component-service-selector>
	    <q-input v-model="newCdn.area" :placeholder="tags.om.area"></q-input>
	    <q-input v-model="newCdn.url" :placeholder="tags.om.cdnHost"></q-input>
	   </q-card-section>
	   <q-card-section align="right">
	    <q-btn :label="tags.ok" color="primary" @click="add"></q-btn>
	    <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
	   </q-card-section>
	  </q-card>
	 </q-popup-proxy>
	</q-btn>
  </q-toolbar>
 </q-header>
 <q-page-container>
  <q-page class="q-pa-md">  
<q-list>
  <q-item>
    <q-item-section>{{tags.om.service}}</q-item-section>
    <q-item-section>{{tags.om.area}}</q-item-section>
    <q-item-section>{{tags.om.cdnHost}}</q-item-section>
  </q-item>
  <q-item v-for="(c,i) in cdns">
    <q-item-section>{{c.service}}</q-item-section>
    <q-item-section>{{c.area}}</q-item-section>
    <q-item-section>{{c.url}}</q-item-section>
    <q-menu touch-position context-menu>
 	 <q-list dense>
	  <q-item clickable v-close-popup @click="remove(c.id,i)">
	   <q-item-section>{{tags.remove}}</q-item-section>
	   <q-item-section avatar><q-icon name="cancel" color="red"></q-icon></q-item-section>
	  </q-item>
	 </q-list>
	</q-menu>
  </q-item>
</q-list>
  </q-page>
 </q-page-container>
</q-layout>
<component-alert-dialog :title="tags.failToCall" :close="tags.close" ref="errDlg"></component-alert-dialog>
`
}