const SERVICE="company";
const EMPTY_BUCKET={provider:'', bucket:'', city:'',
        external:'',inner:'', keyId:'',key:''};
export default {
inject:['service', 'tags'],
data(){return {
    newBucket:{},
    buckets:[]
}},
created() {
    this.newBucket=cloneObj(EMPTY_BUCKET);
    this.query_buckets();
},
methods:{
query_buckets() {
    this.service.request_om({method:"GET",url:"/oss/ombuckets"}, SERVICE).then(resp => {
        if(!resp || resp.code != RetCode.OK) {
            console.warn("error:" + resp.code +",info:" + resp.info);
            return;
        }
        this.buckets=resp.data.buckets;
    })
},
add() {
    var opts={method:"PUT", url:"/oss/setbucket", data:this.newBucket};
    this.service.request_om(opts, SERVICE).then(resp => {
        if(resp.code!=RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.newBucket=cloneObj(EMPTY_BUCKET);
        this.$refs.dlg_add_bucket.hide();
        this.query_buckets();
    });
},
remove(id,i) {
    var opts={method:"DELETE", url:"/oss/rmvbucket?id="+id};
    this.service.request_om(opts, SERVICE).then(resp => {
        if(resp.code!=RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        this.buckets.splice(i,1);
    });
}
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;">
 <q-header class="bg-grey-1 text-primary">
  <q-toolbar>
   <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
   <q-toolbar-title>{{tags.om.bucketset}}</q-toolbar-title>
   <q-btn text-color="primary" icon="add_circle" flat dense>
    <q-popup-proxy ref="dlg_add_bucket">
    <q-card>
     <q-card-section>
      <q-input v-model="newBucket.provider" :placeholder="tags.om.provider"></q-input>
      <q-input v-model="newBucket.bucket" :placeholder="tags.om.bucket"></q-input>
      <q-input v-model="newBucket.city" :placeholder="tags.om.city"></q-input>
      <q-input v-model="newBucket.external" :placeholder="tags.om.external"></q-input>
      <q-input v-model="newBucket.inner" :placeholder="tags.om.inner"></q-input>
      <q-input v-model="newBucket.keyId" :placeholder="tags.om.bktKeyId"></q-input>
      <q-input v-model="newBucket.key" :placeholder="tags.om.bktKey"></q-input>
     </q-card-section>
     <q-card-section align="right">
      <q-btn :label="tags.ok" color="primary" @click="add"></q-btn>
      <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
     </q-card-section>
    </q-card>
    </q-popup-proxy>
   </q-btn>
  </q-toolbar>
 </q-header>
 <q-page-container>
  <q-page class="q-pa-md">  
<q-list>
  <q-item>
    <q-item-section></q-item-section>
    <q-item-section>{{tags.om.bucket}}</q-item-section>
    <q-item-section>{{tags.om.city}}</q-item-section>
    <q-item-section>{{tags.om.bktKey}}</q-item-section>
  </q-item>
  <q-item v-for="(b,i) in buckets">
    <q-item-section>
	 <q-item-label>{{b.bucket}}</q-item-label>
	 <q-item-label caption>{{tags.om.provider}}:{{b.provider}}</q-item-label>
    </q-item-section>
    <q-item-section>
	 <q-item-label>{{b.city}}</q-item-label>
	 <q-item-label caption>{{tags.om.external}}:{{b.external}}</q-item-label>
	 <q-item-label caption>{{tags.om.inner}}:{{b.inner}}</q-item-label>
	</q-item-section>
    <q-item-section>
	 <q-item-label>{{b.key}}</q-item-label>
	 <q-item-label caption>{{tags.om.bktKeyId}}:{{b.keyId}}</q-item-label>
	</q-item-section>
    <q-menu touch-position context-menu>
 	 <q-list dense>
	  <q-item clickable v-close-popup @click="remove(b.id,i)">
	   <q-item-section>{{tags.remove}}</q-item-section>
	   <q-item-section avatar><q-icon name="cancel" color="red"></q-icon></q-item-section>
	  </q-item>
	 </q-list>
	</q-menu>
  </q-item>
</q-list>
  </q-page>
 </q-page-container>
</q-layout>
<component-alert-dialog :title="tags.failToCall" :close="tags.close" ref="errDlg"></component-alert-dialog>
`
}