export default {
inject:['service', 'tags'],
data(){return{
}},
created(){
},
methods:{
},

template: `
<q-layout view="hHh lpr fFf" container style="height:100vh;">
  <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-btn flat icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.tab_om}}</q-toolbar-title>
    </q-toolbar>
  </q-header>
  <q-page-container>
    <q-page class="q-pa-md">
<q-list>
  <q-item clickable @click="service.go_to('/om/cdns')">
    <q-item-section avatar>
      <q-icon color="primary" name="cloud_download"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.om.cdnSet}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
  <q-item clickable @click="service.go_to('/om/buckets')">
    <q-item-section avatar>
      <q-icon color="primary" name="cloud_sync"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.om.bucketSet}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
  <q-item clickable @click="service.go_to('/om/developers')">
    <q-item-section avatar>
      <q-icon color="primary" name="badge"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.om.devSet}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
  <q-item clickable @click="service.go_to('/om/srvnodes')">
    <q-item-section avatar>
      <q-icon color="primary" name="miscellaneous_services"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.om.srvNodes}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
  <q-item clickable @click="service.go_to('/om/dbnodes')">
    <q-item-section avatar>
      <q-icon color="primary" name="storage"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.om.dbNodes}}</q-item-section>
    <q-item-section avatar>
      <q-icon name="chevron_right" class="text-primary"></q-icon>
    </q-item-section>
  </q-item>
</q-list>
    </q-page>
  </q-page-container>
</q-layout>
`
}