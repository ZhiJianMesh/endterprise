const SERVICE="bios";
const DAY_MS=86400000;

export default {
inject:['service', 'tags'],
data() {return {
	name:this.$route.query.service,
	publicKey:"",
	caller:{list:[], name:[], features:""},
    config:{list:[], name:"", val:""},
	pubSrv:{addr:'',start:'',end:''},
	vipSrv:{addr:'',id:''},
	dbList:[],
	pubSrvs:[],
    vipSrvs:[],
	stats:{dlg:false,chart:null,width:0,date:{from:'',to:''},proxyDate:{from:'',to:''}}
}},
created(){
	var dt=new Date();
	var to=dt.getFullYear()+'/'+(dt.getMonth()+1)+'/'+dt.getDate();
	dt.setTime(dt.getTime()-3*DAY_MS);
	var from=dt.getFullYear()+'/'+(dt.getMonth()+1)+'/'+dt.getDate();
	this.stats.date={from:from,to:to};
	this.stats.width=document.documentElement.clientWidth*0.7;
    this.query_service();
    this.query_servers();
},
methods:{
query_service() {
    var url="/service/detail?service=" + this.name;
	this.service.request_om({method:"GET",url:url}, SERVICE).then(resp => {
		if(!resp || resp.code != 0) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
			return;
		}
		this.publicKey=resp.data.publicKey;
		this.caller.list=resp.data.callers;
        this.handleConfigs(resp);
        this.pwds=resp.data.pwds;
		var dbList=[];
        
		resp.data.dbs.forEach(db=>{
			var pos = db.name.lastIndexOf('/');
			var name=db.name.substr(pos + 1); //name,key(type),val(type-value)
			var type='storage';
			if(db.val=="tdb") {
				type="device_hub";
			} else if(db.val=="sdb") {
				type="search";
			}

			dbList.push({name:name,type:type,sType:db.val});
		});
		this.dbList=dbList;
	})
},
query_servers() {
    var url="/om/getservers?service=" + this.name;
    this.service.request_om({method:"GET",url:url}, "httpdns").then(resp => {
        if(!resp || resp.code != RetCode.OK) {
            return;
        }
        this.pubSrvs=resp.data.pubs;
        this.vipSrvs=resp.data.vips;
    })
},
remove_service() {
	if(this.dbs && this.dbs.length>0) {
        this.$refs.errDlg.showErr(RetCode.EXISTS, "dbs is not empty");
		return;
	}
	var url="/service/remove?service="+this.name;
	this.service.request_om({method:"DELETE",url:url}, SERVICE).then(resp => {
		if(!resp || resp.code != 0) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
			return;
		}
		this.service.go_back();
	})
},
set_pub_key(){
    var opts={method:"PUT",url:"/service/setPubKey",
        data:{service:this.name, key:this.publicKey}};
	this.service.request_om(opts,SERVICE).then(resp=>{
        if(!resp || resp.code != RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
        } else {
			this.$refs.dlg_set_pubkey.hide();
		}
    });
},
caller_resp(resp) {
	if(!resp || resp.code != RetCode.OK) {
		this.$refs.errDlg.showErr(resp.code, resp.info);
		return;
	}
	this.caller.list=resp.data.callers;
	this.caller.name=[];
	this.caller.features="";
	this.$refs.dlg_add_caller.hide();
},
add_caller(){
    var opts={method:"POST", url:"/service/addCaller",
        data:{service:this.name,caller:this.caller.name[0],
         features:this.caller.features}};
	this.service.request_om(opts,SERVICE).then(this.caller_resp);	
},
remove_caller(caller){
    var opts={method:"DELETE",
     url:"/service/removeCaller?service="+this.name+"&caller="+caller};
	this.service.request_om(opts,SERVICE).then(this.caller_resp);
},
handleConfigs(resp) {
    var cfgs = {};
	var configs=resp.data.configs;
    for(let i in configs) {
        var k=configs[i].name;
        var v=configs[i].val;
        if(v.length < 45) {
            cfgs[k]=v;
        } else {
            cfgs[k]=v.substr(0,20)+"..."+v.substr(v.length-20);
        }
    }
    this.config.list=cfgs;
},
config_resp(resp) {
    if(!resp || resp.code != 0) {
        this.$refs.errDlg.showErr(resp.code, resp.info);
        return;
    }
    this.config.name="";
    this.config.val="";
	this.service.request_om({method:"GET",url:"/service/getConfigs?service="+this.name}, SERVICE).then(this.handleConfigs);
},
add_config(){
    var opts={method:"PUT", url:"/service/setConfig",
        data:{service:this.name,name:this.config.name,val:this.config.val}};
    this.service.request_om(opts, SERVICE).then(resp => {
		this.config_resp(resp);
		this.$refs.dlg_add_config.hide();	
	});
},
remove_config(itemName){
    var opts={method:"DELETE",
     url:"/service/removeConfig?service="+this.name+"&name="+itemName};
    this.service.request_om(opts,SERVICE).then(this.config_resp);
},
refeshSrvs(resp) {
    if(resp.code != RetCode.OK) {
        this.$refs.errDlg.showErr(resp.code, resp.info);
        return;
    }
	this.query_servers();
},
add_pubsrv(){
    var opts={method:"PUT", url:"/om/setPubSrv",
        data:{service:this.name,addr:this.pubSrv.addr,start:this.pubSrv.start,end:this.pubSrv.end}};
    this.service.request_om(opts, "httpdns").then(resp=>{
		this.$refs.dlg_add_pub.hide();	
		this.refeshSrvs(resp);
	});
},
add_vipsrv(){
    var opts={method:"PUT", url:"/om/setVipSrv",
        data:{service:this.name,addr:this.vipSrv.addr,id:this.vipSrv.id}};
    this.service.request_om(opts, "httpdns").then(resp=>{
		this.$refs.dlg_add_vip.hide();	
		this.refeshSrvs(resp);
	});
},
remove_pubsrv(start){
    var opts={method:"delete", url:"/om/rmvPubSrv?service="+this.name+"&start="+start};
    this.service.request_om(opts, "httpdns").then(this.refeshSrvs);
},
remove_vipsrv(id){
    var opts={method:"delete", url:"/om/rmvVipSrv?service="+this.name+"&id="+id};
    this.service.request_om(opts, "httpdns").then(this.refeshSrvs);
},
initDbs() {
	this.$refs.procDlg.show(this.tags.service.initTitle, this.tags.service.initAlert, 'run_circle',
	    (dlg)=> {
			var opts={method:"get", url:"/initialize"};
			return this.service.request_om(opts, this.name);
        },
        (dlg,resp)=> {
          if(resp.code!=RetCode.OK) {
            dlg.setInfo(formatErr(resp.code, resp.info));
          } else {
            dlg.setInfo(this.tags.service.initSuccess);
			this.refeshSrvs(resp);
          }
        }
	)
},
showStats(){
	this.stats.dlg=true;
	this.stats.chart=Vue.markRaw(echarts.init(document.getElementById('stats_chart')));
	var from=parseInt(new Date(this.stats.date.from).getTime()/DAY_MS)
	var to=parseInt(new Date(this.stats.date.to).getTime()/DAY_MS)
	var opts={method:"GET", url:"/stats/serviceStats?service="+this.name+"&from="+from+"&to="+to};
    this.service.request_om(opts, "appstore").then(resp=>{
		if(resp.code != RetCode.OK) {
			this.$refs.errDlg.showErr(resp.code, resp.info);
			return;
		}
		if(resp.data.stats.length==0) {
			return;
		}
		var dt=new Date();
		var cols=resp.data.cols;
		var cn=cols.length;
		var data=[];
		
		for(var l of resp.data.stats) {
			var d={};
			for(var i=0; i<cn; i++) {
				d[cols[i]]=l[i];
			}
			data.push(d);
		}
		var xAxis=[];
		var apis=[];
		var fails=[];
		var excs=[];
		var n,t,h,oldDay=data[0].day;
		for(var l of data) {
			n=l.day-oldDay;
			if(n>1) {//中间存在无记录的天
				n=(n-1)*24;
				for(var i=0;i<n;i++,t+=3600000) {
					dt.setTime(t);
					apis.push(0);
					fails.push(0);
					excs.push(0);
					h=dt.getHours();
					if(h==0) {
						xAxis.push(dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate());
					}else{
						xAxis.push(h+':00');
					}
				}					
			}
			t=l.day*DAY_MS;
			for(var i=0;i<24;i++,t+=3600000) {
				dt.setTime(t);
				apis.push(l['h'+i]);
				h=dt.getHours();
				if(h==0) {
					xAxis.push(dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate());
					fails.push(l.fail);
					excs.push(l.exc);
				}else{
					xAxis.push(h+':00');
					fails.push(0);
					excs.push(0);
				}
			}
			oldDay=l.day;
		}
		var series=[
			{name:this.tags.service.requests, type:'bar', data:apis, yAxisIndex:0},
			{name:this.tags.service.fails, type:'line', data:fails, yAxisIndex:0, itemStyle:{color:'orange'}},
			{name:this.tags.service.excs, type:'line', data:excs, yAxisIndex:0, itemStyle:{color:'red'}}
		];
		
		this.stats.chart.setOption({
			title: {show:false},
			tooltip: {},
			legend: {type:'scroll', bottom:10, width:this.stats.width},
			grid: {left:'0%', containLabel:true},
			xAxis: {data:xAxis, type:'category',axisLabel:{interval:(i,l)=>{return l.length>5}}},
			yAxis: [{name:this.tags.service.unit, minInterval:1}],
			series: series
		});
	});
},
statsDateChanged() {
	if(this.stats.proxyDate) {
		this.stats.date=this.stats.proxyDate;
		this.showStats();
	}
}
},
template:`
<q-layout view="hHh lpr fFf" container style="height:100vh">
 <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
	  <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{name}}{{tags.detailInfo}}</q-toolbar-title>
      <q-btn flat round icon="bar_chart" dense @click="stats.dlg=true"></q-btn>
    </q-toolbar>
 </q-header>

 <q-page-container>
   <q-page class="q-pa-md">
<q-banner rounded class="bg-grey-3 text-h5" dense>{{tags.service.pubKey}}</q-banner>
<div>{{publicKey}}
 <q-popup-edit v-model="publicKey" v-slot="scope" @update:model-value="set_pub_key"
  buttons :label-set="tags.ok" :label-cancel="tags.cancel" auto-save ref="dlg_set_pubkey">
  <q-input v-model="scope.value" dense autofocus @keyup.enter="scope.set"></q-input>
 </q-popup-edit>
</div>

<q-banner rounded class="bg-grey-3 text-h5 q-mt-lg" dense inline-actions>{{tags.service.db}}
 <template v-slot:action>
  <q-btn text-color="primary" icon="history" flat dense @click="initDbs"></q-btn>
 </template>
</q-banner>
<q-list>
  <q-item v-for="db in dbList">
	<q-item-section>{{db.name}}</q-item-section>
	<q-item-section avatar><q-chip color="green" text-color="white" :icon="db.type">{{db.sType}}</q-chip></q-item-section>
  </q-item>
</q-list>

<q-banner rounded class="bg-grey-3 text-h5 q-mt-lg" dense inline-actions>{{tags.caller}}
 <template v-slot:action>
  <q-btn text-color="primary" icon="add_circle" flat dense>
   <q-popup-proxy ref="dlg_add_caller">
	<q-card style="min-width:30vw;">
	 <q-card-section>
	  <component-service-selector :label="tags.caller" :services="caller.name" :multi="false" :useid="false"></component-service-selector>
	  <q-input v-model="caller.features" :placeholder="tags.features"></q-input>
	 </q-card-section>
	 <q-card-section align="right">
	  <q-btn :label="tags.ok" color="primary" @click="add_caller"></q-btn>
	  <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
	 </q-card-section>
	</q-card>
   </q-popup-proxy>
  </q-btn>
 </template>
</q-banner>
<q-list>
  <q-item v-for="c in caller.list">
    <q-item-section>{{c.name}}</q-item-section>
    <q-item-section>{{c.val}}</q-item-section>
    <q-item-section avatar @click="remove_caller(c.name)">
      <q-icon color="primary" text-color="white" name="delete"></q-icon>
    </q-item-section>
  </q-item>
</q-list>

<q-banner rounded class="bg-grey-3 text-h5 q-mt-lg" dense inline-actions>{{tags.configs}}
 <template v-slot:action>
  <q-btn text-color="primary" icon="add_circle" flat dense>
   <q-popup-proxy ref="dlg_add_config">
	<q-card style="min-width:30vw;">
	 <q-card-section>
	  <q-input v-model="config.name" :placeholder="tags.configKey"></q-input>
	  <q-input v-model="config.val" :placeholder="tags.configVal"></q-input>
	 </q-card-section>
	 <q-card-section align="right">
	  <q-btn :label="tags.ok" color="primary" @click="add_config"></q-btn>
	  <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
	 </q-card-section>
	</q-card>
   </q-popup-proxy>
  </q-btn>
 </template>
</q-banner>
<q-list>
  <q-item v-for="(v,k) in config.list">
    <q-item-section>{{k}}</q-item-section>
    <q-item-section>{{v}}</q-item-section>
    <q-item-section avatar>
      <q-icon color="primary" text-color="white" name="delete" @click="remove_config(k)"></q-icon>
    </q-item-section>
  </q-item>
</q-list>

<q-banner rounded class="bg-grey-3 text-h5 q-mt-lg" dense inline-actions>{{tags.service.pubSrvs}}
 <template v-slot:action>
  <q-btn text-color="primary" icon="add_circle" flat dense>
   <q-popup-proxy ref="dlg_add_pub">
	<q-card style="min-width:30vw;">
	 <q-card-section>
	  <q-input v-model="pubSrv.addr" :placeholder="tags.service.addr"></q-input>
	  <q-input v-model="pubSrv.start" :placeholder="tags.service.segStart"></q-input>
	  <q-input v-model="pubSrv.end" :placeholder="tags.service.segEnd"></q-input>
	 </q-card-section>
	 <q-card-section align="right">
	  <q-btn :label="tags.ok" color="primary" @click="add_pubsrv"></q-btn>
	  <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
	 </q-card-section>
	</q-card>
   </q-popup-proxy>
  </q-btn>
 </template>
</q-banner>
<q-list>
  <q-item v-for="s in pubSrvs">
    <q-item-section>{{s.addr}}</q-item-section>
    <q-item-section>{{s.start}}</q-item-section>
    <q-item-section>{{s.end}}</q-item-section>
    <q-item-section avatar>
      <q-icon color="primary" text-color="white" name="delete" @click="remove_pubsrv(s.start)"></q-icon>
    </q-item-section>
  </q-item>
</q-list>

<q-banner rounded class="bg-grey-3 text-h5 q-mt-lg" dense inline-actions>{{tags.service.vipSrvs}}
 <template v-slot:action>
  <q-btn text-color="primary" icon="add_circle" flat dense>
   <q-popup-proxy ref="dlg_add_vip">
	<q-card style="min-width:30vw;">
	 <q-card-section>
	  <q-input v-model="vipSrv.addr" :placeholder="tags.service.addr"></q-input>
	  <q-input v-model="vipSrv.id" :placeholder="tags.service.vipId"></q-input>
	 </q-card-section>
	 <q-card-section align="right">
	  <q-btn :label="tags.ok" color="primary" @click="add_vipsrv"></q-btn>
	  <q-btn flat :label="tags.cancel" color="primary" v-close-popup></q-btn>
	 </q-card-section>
	</q-card>
   </q-popup-proxy>
  </q-btn>
 </template>
</q-banner>
<q-list>
  <q-item v-for="s in vipSrvs">
    <q-item-section>{{s.addr}}</q-item-section>
    <q-item-section>{{s.id}}</q-item-section>
    <q-item-section avatar>
      <q-icon color="primary" text-color="white" name="delete" @click="remove_vipsrv(s.id)"></q-icon>
    </q-item-section>
  </q-item>
</q-list>
	</q-page>
  </q-page-container>
</q-layout>
<component-process-dialog ref="procDlg"></component-process-dialog>
<component-alert-dialog ref="errDlg" :title="tags.failToCall" :close="tags.close"></component-alert-dialog>

<!-- 请求统计弹窗 -->
<q-dialog v-model="stats.dlg" no-backdrop-dismiss @show="showStats">
  <q-card style="min-width:80vw;">
    <q-card-section class="row items-center q-pb-none">
      <div class="text-h6">{{tags.service.requests}}</div>
	  <q-space></q-space>
	  <q-btn icon="event" flat>
        <q-popup-proxy cover transition-show="scale" transition-hide="scale">
          <q-date v-model="stats.proxyDate" range>
            <div class="row items-center justify-end">
              <q-btn :label="tags.ok" color="primary" @click="statsDateChanged" v-close-popup></q-btn>
              <q-btn :label="tags.close" color="primary" flat v-close-popup></q-btn>
            </div>
          </q-date>
        </q-popup-proxy>
		{{stats.date.from}} => {{stats.date.to}}
	  </q-btn>
	  <q-space></q-space>
      <q-btn icon="close" flat round dense v-close-popup></q-btn>
    </q-card-section>
    <q-card-section class="q-pt-none">
	 <div id="stats_chart" style="width:78vw;height:70vh;"></div>
    </q-card-section>
  </q-card>
</q-dialog>
`}