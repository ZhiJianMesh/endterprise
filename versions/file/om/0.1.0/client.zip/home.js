export default {
inject:['service', 'tags'],
data() {return {
    auth:{cid:'',dlg:false,pwd:'',visible:false}
}},
methods:{
showLogin() {
    if(this.service.getToken("company")) {//任何一个存在都可以，因为是同时申请的
        this.service.go_to("/remote");
    } else {
        this.auth.dlg=true;
    }
},
connect_private() {
    this.service.login_private(this.auth.cid, this.auth.pwd, ["company","httpdns","backend"]).then(resp=>{
        if(resp.code!=RetCode.OK) {
            return resp;
        }
        this.service.setRemoteCom(this.auth.cid,resp.data.outsideAddr);
        for(var i in resp.data.tokens) {
			this.service.setToken(i,resp.data.tokens[i]);
		}
        return this.service.command({cmd:'query'});
    }).then(resp => {
        if(resp.code!=RetCode.OK) {
            this.service.clrRemoteCom();
            this.$refs.alertDlg.showErr(resp.code, resp.info);
            return resp;
        }
        this.service.remoteCom.name=resp.data.companyName;
        this.auth.dlg=false;
        this.service.go_to('/remote');
    });
}
},
template: `
<q-layout view="hHh lpr fFf" container style="height:100vh">
  <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-toolbar-title>{{tags.app_name}}</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
    <q-page class="q-pa-md">
<q-list>
  <q-item clickable @click="service.go_to('/service')">
    <q-item-section avatar>
      <q-icon color="primary" name="apps"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.tab_service}}</q-item-section>
  </q-item>
  <q-item clickable @click="service.go_to('/company')">
    <q-item-section avatar>
      <q-icon color="primary" name="business"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.tab_company}}</q-item-section>
  </q-item>
  <q-item clickable @click="service.go_to('/om')">
    <q-item-section avatar>
      <q-icon color="primary" name="manage_accounts"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.tab_om}}</q-item-section>
  </q-item>
  <q-item clickable @click="showLogin">
    <q-item-section avatar>
      <q-icon color="primary" name="connect_without_contact"></q-icon>
    </q-item-section>
    <q-item-section>{{tags.tab_remote}}</q-item-section>
  </q-item>
</q-list>
    </q-page>
  </q-page-container>
</q-layout>

<q-dialog v-model="auth.dlg"> <!-- 登录公司获得公司级token -->
  <q-card style="min-width:62vw;max-width:80vw">
    <q-card-section>
      <div class="text-h6">{{tags.auth}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
      <q-input dense v-model="auth.cid" autofocus :label="tags.cid"></q-input>
      <q-input dense v-model="auth.pwd" :type="auth.visible?'text':'password'" :label="tags.pwd">
        <template v-slot:append>
          <q-icon :name="auth.visible ? 'visibility_off':'visibility'"
            class="cursor-pointer" @click="auth.visible=!auth.visible"></q-icon>
        </template>
      </q-input>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn color="primary" :label="tags.ok" @click="connect_private"></q-btn>
      <q-btn color="primary" flat :label="tags.cancel" v-close-popup></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>

<component-alert-dialog :title="tags.alert" :errMsgs="tags.errMsgs"
 :close="tags.close" ref="alertDlg"></component-alert-dialog>
`}