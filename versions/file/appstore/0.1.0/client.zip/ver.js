export default {
inject:['service', 'tags'],
data() {return {
	serviceId:this.$route.query.service,
    ver:this.$route.query.ver,
	sVer:App.intToVer(this.$route.query.ver),
    dtl:{minCVer:0,size:0,digest:'',cmt:'',service:''},
	
	dependencies:[],
	rules:[],
	features:[],

	newDep:{service:[],minVer:'',features:'',dlg:false},
	newRule:{cidStart:0,cidEnd:2147483647,area:0,ver:'0.0.0',risk:0,evm:'',dlg:false},
	newFeature:{feature:'',cmt:'',dlg:false}	
}},
created(){
	this.query_dtl();
},
methods:{
query_dtl() {
    var url="/api/my/verdetail?service="+this.serviceId+"&ver="+this.ver;
    request({method:"GET", url:url, private:false},this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		var d=resp.data;
		var list=[];
		
		this.dtl={service:d.service, size:d.size, digest:d.digest, cmt:d.cmt, minCVer:App.intToVer(d.minCVer)};
		for(var l of d.dependencies) {
			l.minVer=App.intToVer(l.minVer);
			list.push(l); //dependency,minVer,features,name,displayName
		}
		this.dependencies = list;
		
		list=[];
		for(var l of d.rules) {
			l.sVer=App.intToVer(l.ver);
			list.push(l); //cidStart,cidEnd,area,ver,risk,evm
		}
		this.rules = list;
		this.features = d.features;
    });
},
save_base(v,v0) {
    var reqDta={
		service:this.serviceId,
		ver:this.ver,
		minCVer:App.verToInt(v.minCVer),
		size:v.size,
		digest:v.digest,
		cmt:v.cmt
	}
    request({method:"POST", url:"/api/my/updateVersion", data:reqDta},this.service.name).then(resp=>{
        if(resp.code != 0) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.dtl.minCVer=v.minCVer;
		this.dtl.size=v.size;
		this.dtl.cmt=v.cmt;
		this.dtl.digest=v.digest;
    });
},
open_add_dep() {
	this.newDep={service:[],minVer:'',features:'',dlg:true};
},
rmv_dep(depId) {
	var url="/api/my/rmvDependency?service="+this.serviceId+"&ver="+this.ver+"&dependency="+depId;
    request({method:"DELETE", url:url},this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.query_dtl();
    });
},
add_dep(){
	var reqDta={
		service:this.serviceId,
		ver:this.ver,
		dependency:this.newDep.service[0],
		minVer:App.verToInt(this.newDep.minVer),
		features:this.newDep.features
	};
    request({method:"POST", url:"/api/my/addDependency", data:reqDta}, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.newDep.dlg=false;
		this.query_dtl();
    });
},
open_add_rule(){
	this.newRule={cidStart:0,cidEnd:2147483647,area:0,ver:'0.0.0',risk:0,evm:'',dlg:true};
},
add_rule(){
	var reqDta={
		service:this.serviceId,
		ver:App.verToInt(this.newRule.ver),
		cidStart:this.newRule.cidStart,
		cidEnd:this.newRule.cidEnd,
		area:this.newRule.area,
		dstVer:this.ver,
		risk:this.newRule.risk,
		evm:this.newRule.evm
	};
    request({method:"POST", url:"/api/my/addRule", data:reqDta}, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.newRule.dlg=false;
		this.query_dtl();
    });
},
rmv_rule(cidStart,area,ver) {
	var url="/api/my/rmvRule?service="+this.serviceId+"&ver="+ver+"&cidStart="+cidStart+"&area="+area;
    request({method:"DELETE", url:url},this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.query_dtl();
    });
},
open_add_feature(){
	this.newFeature={feature:'',cmt:'',dlg:true};
},
add_feature(){
	var reqDta={
		service:this.serviceId,
		ver:this.ver,
		feature:this.newFeature.feature,
		cmt:this.newFeature.cmt
	};
    request({method:"POST", url:"/api/my/addFeature", data:reqDta}, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.newFeature.dlg=false;
		this.query_dtl();
    });
},
rmv_feature(feature) {
	var url="/api/my/rmvFeature?service="+this.serviceId+"&ver="+this.ver+"&feature="+encodeURIComponent(feature);
    request({method:"DELETE", url:url},this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.query_dtl();
    });
}
},

template:`
<q-layout view="lHh lpr lFf" container style="height:100vh">
  <q-header class="bg-grey-1 text-primary" elevated>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{dtl.service}}-{{sVer}}</q-toolbar-title>
    </q-toolbar>
  </q-header>
  <q-page-container>
    <q-page class="q-px-none q-pb-lg">
<q-banner dense inline-actions class="text-dark bg-blue-grey-1">{{tags.baseInfo}}
  <template v-slot:action>
    <q-icon name="edit" color="primary"></q-icon>
    <q-popup-edit v-model="dtl" cover="false" buttons auto-save v-slot="scope"
      @save="save_base" :label-set="tags.save" :label-cancel="tags.cancel" style="min-width:40vw">
     <q-input v-model="scope.value.minCVer" :label="tags.ver.minCVer" 
     :rules="[v=>/^\\d{1,3}(\\.\\d{1,3}){2}$/.test(v) || tags.verPls]" dense></q-input>
     <q-input v-model="scope.value.size" :label="tags.ver.size" dense type="number"></q-input>
     <q-input v-model="scope.value.digest" :label="tags.ver.digest" dense></q-input>
     <q-input v-model="scope.value.cmt" :label="tags.ver.cmt" dense type="textarea"></q-input>
    </q-popup-edit>
  </template>
</q-banner>
<q-list dense>
 <q-item>
  <q-item-section side>{{tags.ver.minCVer}}</q-item-section>
  <q-item-section>{{dtl.minCVer}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.ver.size}}</q-item-section>
  <q-item-section>{{dtl.size}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.ver.digest}}</q-item-section>
  <q-item-section>{{dtl.digest}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.ver.cmt}}</q-item-section>
  <q-item-section>{{dtl.cmt}}</q-item-section>
 </q-item>
</q-list>

<q-banner dense inline-actions class="q-mb-md text-dark bg-blue-grey-1">
{{tags.dependencies}}
  <template v-slot:action>
    <q-icon name="add_circle" color="primary" @click="open_add_dep"></q-icon>
  </template>
</q-banner>
<q-markup-table flat dense>
  <thead>
	<tr>
	  <th class="text-left">{{tags.dep.name}}</th>
	  <th class="text-right">{{tags.dep.minVer}}</th>
	  <th class="text-right">{{tags.dep.features}}</th>
	  <th class="text-right"></th>
	</tr>
  </thead>
  <tbody>
	<tr v-for="d in dependencies">
	 <td class="text-left">{{d.name}}({{d.displayName}})</td>
	 <td class="text-right">{{d.minVer}}</td>
	 <td class="text-right">{{d.features}}</td>
	 <td class="text-right"><q-icon name="delete" @click="rmv_dep(d.dependency)" color="red" size="2em"></q-icon></td>
	</tr>
  </tbody>
</q-markup-table>		

<q-banner dense inline-actions class="q-mb-md text-dark bg-blue-grey-1">
{{tags.rules}}
  <template v-slot:action>
    <q-icon name="add_circle" color="primary" @click="open_add_rule"></q-icon>
  </template>
</q-banner>
<q-markup-table flat dense>
  <thead>
	<tr>
	  <th class="text-left">{{tags.rule.ver}}</th>
	  <th class="text-right">{{tags.rule.area}}</th>
	  <th class="text-right">{{tags.rule.cidStart}}</th>
	  <th class="text-right">{{tags.rule.cidEnd}}</th>
	  <th class="text-right"></th>
	</tr>
  </thead>
  <tbody>
	<tr v-for="r in rules">
	 <td class="text-left">
	  <q-list flat dense>
       <q-item>
        <q-item-section>
          <q-item-label>{{r.sVer}}</q-item-label>
          <q-item-label caption>{{tags.rule.evm}}:{{r.evm}},{{tags.rule.risk}}:{{tags.riskLevels[r.risk].label}}</q-item-label>
          <q-item-label caption></q-item-label>
        </q-item-section>
       </q-item>
	  </q-list>
	 </td>
	 <td class="text-right">{{r.area}}</td>
	 <td class="text-right">{{r.cidStart}}</td>
	 <td class="text-right">{{r.cidEnd}}</td>
	 <td class="text-right"><q-icon name="delete" @click="rmv_rule(r.cidStart,r.area,r.ver)" color="red" size="2em"></q-icon></td>
	</tr>
  </tbody>
</q-markup-table>	

<q-banner dense inline-actions class="q-mb-md text-dark bg-blue-grey-1">
{{tags.features}}
  <template v-slot:action>
    <q-icon name="add_circle" color="primary" @click="open_add_feature"></q-icon>
  </template>
</q-banner>
<q-markup-table flat dense>
  <thead>
   <tr>
	<th class="text-left">{{tags.feature.name}}</th>
	<th class="text-right">{{tags.feature.cmt}}</th>
	<th></th>
   </tr>
  </thead>
  <tbody>
   <tr v-for="f in features">
	<td class="text-left">{{f.feature}}</td>
	<td class="text-right">{{f.cmt}}</td>
	<td class="text-right"><q-icon name="delete" @click="rmv_feature(f.feature)" color="red" size="2em"></q-icon></td>
   </tr>
  </tbody>
</q-markup-table>

    </q-page>
  </q-page-container>
</q-layout>

<!-- 新建依赖服务弹窗 -->
<q-dialog v-model="newDep.dlg">
  <q-card style="min-width:70vw">
    <q-card-section>
      <div class="text-h6">{{tags.addDep}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
	 <component-service-selector :label="tags.dep.name" :services="newDep.service" :multi="false" :useid="true"></component-service-selector>
	 <q-input v-model="newDep.minVer" :label="tags.dep.minVer" dense
     :rules="[v=>/^\\d{1,3}(\\.\\d{1,3}){2}$/.test(v) || tags.verPls]"></q-input>
     <q-input v-model="newDep.features" :label="tags.dep.features" dense></q-input>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn flat :label="tags.ok" color="primary" @click="add_dep"></q-btn>
      <q-btn flat :label="tags.close" color="primary" v-close-popup></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>

<!-- 新建分发规则弹窗 -->
<q-dialog v-model="newRule.dlg">
  <q-card style="min-width:70vw">
    <q-card-section>
      <div class="text-h6">{{tags.addRules}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
     <q-input v-model="newRule.cidStart" :label="tags.rule.cidStart" dense type="number"></q-input>
     <q-input v-model="newRule.cidEnd" :label="tags.rule.cidEnd" dense type="number"></q-input>
     <q-input v-model="newRule.area" :label="tags.rule.area" dense type="number"></q-input>
	 <q-input v-model="newRule.ver" :label="tags.rule.ver" dense
     :rules="[v=>/^\\d{1,3}(\\.\\d{1,3}){2}$/.test(v) || tags.verPls]"></q-input>
     <q-input v-model="newRule.evm" :label="tags.rule.evm" dense></q-input>
	 <q-select v-model="newRule.risk" :options="tags.riskLevels" :label="tags.rule.risk" emit-value map-options></q-select>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn flat :label="tags.ok" color="primary" @click="add_rule"></q-btn>
      <q-btn flat :label="tags.close" color="primary" v-close-popup></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>

<!-- 新建特性弹窗 -->
<q-dialog v-model="newFeature.dlg">
  <q-card style="min-width:70vw">
    <q-card-section>
      <div class="text-h6">{{tags.addFeatures}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
     <q-input v-model="newFeature.feature" :label="tags.feature.name" dense></q-input>
     <q-input v-model="newFeature.cmt" :label="tags.feature.cmt" dense type="textarea"></q-input>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn flat :label="tags.ok" color="primary" @click="add_feature"></q-btn>
      <q-btn flat :label="tags.close" color="primary" v-close-popup></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>

<component-alert-dialog :title="tags.failToCall" :errMsgs="tags.errMsgs" :close="tags.close" ref="errMsg"></component-alert-dialog>
`
}