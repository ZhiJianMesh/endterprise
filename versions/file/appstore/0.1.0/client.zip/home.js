export default {
inject:['service', 'tags'],
data() {return {
    apps:[], //服务列表
    newApp:{service:'',displayName:'',ui:'Y',type:0,level:0,cmt:'',author:this.service.userInfo.account},
    appPg:{cur:1,max:0},
	crtDlg:false
}},
created(){
    this.my_apps(0);
},
methods:{
my_apps(offset) {
    var url="/my/list?offset="+ offset + "&num=" + this.service.NUM_PER_PAGE;
    request({method:"GET",url:url}, this.service.name).then(resp=>{
        if(resp.code!=RetCode.OK) {
            this.apps=[];
            this.appPg.max=0;
        } else {
			var cols=resp.data.cols;
			var dt=new Date();
			var colNum=cols.length;
			var lines=[];
			for(var l of resp.data.services) {
				var line={};
				for(var i=0; i<colNum; i++) {
					line[cols[i]]=l[i];
				}
				dt.setTime(line.recentUpd);
				line.recentUpd=dt.toLocaleString();
				lines.push(line);
			}
            this.apps=lines;
            this.appPg.max=Math.ceil(resp.data.total/this.service.NUM_PER_PAGE);
        }
    });
},
change_app_page(page) {
    this.my_apps((parseInt(page)-1)*this.service.NUM_PER_PAGE);
},
open_create_app(student){
	this.newApp.service='';
	this.newApp.displayName='';
	this.newApp.ui='Y';
	this.newApp.type=0;
	this.newApp.level=100;
	this.newApp.cmt='';
	this.crtDlg=true;
},
create_app() {
    request({method:"POST", url:"/api/my/create", data:this.newApp}, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
        this.crtDlg=false;
		this.appPg.cur=1;
        this.my_apps(0);
    })
},
rmv_app(service) {
    request({method:"delete", url:"/api/my/rmv?service="+service}, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.appPg.cur=1;
        this.my_apps(0);
    })
}
},

template:`
<q-layout view="lHh lpr lFf" container style="height:100vh">
  <q-header class="bg-grey-1 text-primary" elevated>
   <q-toolbar>
    <q-avatar square><img src="./favicon.png"></q-avatar>
    <q-toolbar-title>{{tags.app_name}}</q-toolbar-title>
	<q-btn icon="add" @click="open_create_app" flat dense></q-btn>
   </q-toolbar>
  </q-header>
  <q-page-container>
    <q-page class="q-pa-md">
<div class="q-pa-lg flex flex-center" v-if="appPg.max>1">
 <q-pagination v-model="appPg.cur" color="primary" :max="appPg.max" max-pages="10"
  boundary-numbers="false" @update:model-value="change_app_page"></q-pagination>
</div>

<q-markup-table flat>
 <thead><tr>
  <th class="text-left">{{tags.app.service}}</th>
  <th class="text-right">{{tags.app.author}}</th>
  <th class="text-right">{{tags.app.recentUpd}}</th>
  <th class="text-right"></th>
 </tr></thead>
 <tbody>
 <tr v-for="v in apps">
  <td class="text-left" @click="service.jumpTo('/app?id='+v.id)">{{v.service}}({{v.displayName}})</td>
  <td class="text-right">{{v.author}}</td>
  <td class="text-right">{{v.recentUpd}}</td>
  <td class="text-right"><q-icon name="delete" @click="rmv_app(v.id)" color="red" size="2em" v-if="v.power=='O'"></q-icon></td>
 </tr>
 </tbody>
</q-markup-table>

<q-dialog v-model="crtDlg">
  <q-card style="min-width:70vw" class="q-pa-md">
    <q-card-section>
      <div class="text-h6">{{tags.app.create}}
	  <q-chip square>
        <q-avatar><q-icon name="person" color="primary" size="1.5em"></q-icon></q-avatar>
        {{service.userInfo.account}}
      </q-chip>
    </q-card-section>
    <q-card-section>
     <q-input v-model="newApp.service" :label="tags.app.service" dense
     :rules="[v=>/[a-z|A-Z|0-9|_]{1,30}/.test(v)|| tags.servicePls]"></q-input>
     <q-input v-model="newApp.displayName" :label="tags.app.name" maxlength=80
     :rules="[v=>v!=''|| tags.namePls]" dense></q-input>
	 <div v-if="service.userInfo.account=='admin'">
      <q-select v-model="newApp.type" :options="tags.serviceTypes" :label="tags.app.type" emit-value map-options></q-select>
      <q-input v-model="newApp.level" :label="tags.app.level" dense></q-input>
	 </div>
     <q-input v-model="newApp.cmt" :label="tags.app.cmt" dense type="textarea"></q-input>
     <q-checkbox v-model="newApp.ui" :label="tags.app.ui" true-value="Y" false-value="N" dense></q-checkbox>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn flat :label="tags.close" color="secondary" v-close-popup></q-btn>
      <q-btn :label="tags.ok" color="primary" @click="create_app"></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>
<component-alert-dialog :title="tags.failToCall" :errMsgs="tags.errMsgs" :close="tags.close" ref="errMsg"></component-alert-dialog>
`
}