export default {
inject:['service', 'tags'],
data() {return {
    id:this.$route.query.id,
    app:{service:'',displayName:'',author:'',type:0,installs:0,recentUpd:'',ver:'',ui:'Y',cmt:'',power:''},
	vers:[],
	newVer:{ver:'',minCVer:'',size:'',digest:'',cmt:'',dlg:false},
	stats:{dlg:false,chart:null,width:0,date:{from:'',to:''},proxyDate:{from:'',to:''}}
}},
created(){
	this.query_dtl();
	var dt=new Date();
	var to=dt.getFullYear()+'/'+(dt.getMonth()+1)+'/'+dt.getDate();
	dt.setTime(dt.getTime()-3*this.service.DAY_MS);
	var from=dt.getFullYear()+'/'+(dt.getMonth()+1)+'/'+dt.getDate();
	this.stats.date={from:from, to:to};
	this.stats.width=document.documentElement.clientWidth*0.7;
},
methods:{
query_dtl() {
    var url="/api/my/detail?id="+this.id;
    request({method:"GET", url:url},this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		var d=resp.data; //service,displayName,author,type,level,installs,recentUpd,ver,ui,cmt,power
		this.app={
			service:d.service, displayName:d.displayName, author:d.author,
			cmt:d.cmt, ui:d.ui, level:d.level, type:d.type,installs:d.installs,power:d.power,
		    recentUpd:new Date(d.recentUpd).toLocaleString(),
			ver:App.intToVer(d.ver)
		};
		
		var list=[];
		for(var l of resp.data.vers) {
			l['sVer']=App.intToVer(l.ver);
			l.minCVer=App.intToVer(l.minCVer);
			list.push(l);
		}
		this.vers=list;
    });
},
save_base(v,v0) {
    var reqDta={
		service:this.id,
		author:v.author,
		level:v.level,
		displayName:v.displayName,
		cmt:v.cmt,
		ui:v.ui
	}
    request({method:"POST", url:"/api/my/update", data:reqDta},this.service.name).then(resp=>{
        if(resp.code != 0) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.app.displayName=v.displayName;
		this.app.level=v.level;
		this.app.cmt=v.cmt;
		this.app.author=v.author;
		this.app.ui=v.ui;
    });
},
add_ver(){
	var url="/api/my/addVersion";
	var reqDta={
		service:this.id,
		ver:App.verToInt(this.newVer.ver),
		minCVer:App.verToInt(this.newVer.minCVer),
		size:this.newVer.size,
		digest:this.newVer.digest,
		cmt:this.newVer.cmt
	}
    request({method:"POST", url:url, data:reqDta}, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.newVer.dlg=false;
		this.query_dtl();
    });
},
rmv_ver(ver) {
	var url="/api/my/rmvVersion?service="+this.id+"&ver="+ver;
    request({method:"DELETE", url:url}, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
            return;
        }
		this.query_dtl();
    });
	return false;//阻止事件冒泡
},
open_crt_ver(){
	this.newVer={ver:'',minCVer:'',size:'',digest:'',cmt:'',dlg:true};
},
showStats(){
	this.stats.dlg=true;
	this.stats.chart=Vue.markRaw(echarts.init(document.getElementById('stats_chart')));
	var from=parseInt(new Date(this.stats.date.from).getTime()/this.service.DAY_MS)
	var to=parseInt(new Date(this.stats.date.to).getTime()/this.service.DAY_MS)
	var url="/api/my/stats?service="+this.id+"&from="+from+"&to="+to;
    request({method:"GET", url:url}, this.service.name).then(resp=>{
		if(resp.code != RetCode.OK) {
			this.$refs.errMsg.showErr(resp.code, resp.info);
			return;
		}
		if(resp.data.stats.length==0) {
			return;
		}
		var dt=new Date();
		var cols=resp.data.cols;
		var cn=cols.length;
		var data=[];
		
		for(var l of resp.data.stats) {
			var d={};
			for(var i=0; i<cn; i++) {
				d[cols[i]]=l[i];
			}
			data.push(d);
		}
		var xAxis=[];
		var apis=[];
		var fails=[];
		var excs=[];
		var n,t,h,oldDay=data[0].day;
		for(var l of data) {
			n=l.day-oldDay;
			if(n>1) {//中间存在无记录的天
				n=(n-1)*24;
				for(var i=0;i<n;i++,t+=3600000) {
					dt.setTime(t);
					apis.push(0);
					fails.push(0);
					excs.push(0);
					h=dt.getHours();
					if(h==0) {
						xAxis.push(dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate());
					}else{
						xAxis.push(h+':00');
					}
				}					
			}
			t=l.day*this.service.DAY_MS;
			for(var i=0;i<24;i++,t+=3600000) {
				dt.setTime(t);
				apis.push(l['h'+i]);
				h=dt.getHours();
				if(h==0) {
					xAxis.push(dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate());
					fails.push(l.fail);
					excs.push(l.exc);
				}else{
					xAxis.push(h+':00');
					fails.push(0);
					excs.push(0);
				}
			}
			oldDay=l.day;
		}
		var series=[
			{name:this.tags.stats.requests, type:'bar', data:apis, yAxisIndex:0},
			{name:this.tags.stats.fails, type:'line', data:fails, yAxisIndex:0, itemStyle:{color:'orange'}},
			{name:this.tags.stats.excs, type:'line', data:excs, yAxisIndex:0, itemStyle:{color:'red'}}
		];
		
		this.stats.chart.setOption({
			title: {show:false},
			tooltip: {},
			legend: {type:'scroll', bottom:10, width:this.stats.width},
			grid: {left:'0%', containLabel:true},
			xAxis: {data:xAxis, type:'category',axisLabel:{interval:(i,l)=>{return l.length>5}}},
			yAxis: [{name:this.tags.stats.unit, minInterval:1}],
			series: series
		});
	});
}
},

template:`
<q-layout view="lHh lpr lFf" container style="height:100vh">
  <q-header class="bg-grey-1 text-primary" elevated>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{app.service}}</q-toolbar-title>
	  <q-btn flat round icon="bar_chart" dense @click="stats.dlg=true"></q-btn>
    </q-toolbar>
  </q-header>
  <q-page-container>
    <q-page class="q-px-none q-pb-lg">
<q-banner dense inline-actions class="text-dark bg-blue-grey-1">{{tags.baseInfo}}
  <template v-slot:action>
    <q-icon name="edit" color="primary"></q-icon>
    <q-popup-edit v-model="app" cover="false" buttons auto-save v-slot="scope"
      @save="save_base" :label-set="tags.save" :label-cancel="tags.cancel" style="min-width:40vw">
     <q-input v-model="scope.value.displayName" :label="tags.app.name" maxlength=80
     :rules="[v=>v!=''|| tags.namePls]" dense></q-input>
	 <div v-if="service.userInfo.account=='admin'">
      <q-select v-model="scope.value.type" :options="tags.serviceTypes" :label="tags.app.type" emit-value map-options></q-select>
      <q-input v-model="scope.value.level" :label="tags.app.level" dense></q-input>
	 </div>
     <q-input v-model="scope.value.cmt" :label="tags.app.cmt" dense type="textarea"></q-input>
     <q-checkbox v-model="scope.value.ui" :label="tags.app.ui" true-value="Y" false-value="N" dense></q-checkbox>
    </q-popup-edit>
  </template>
</q-banner>
<q-list dense>
 <q-item>
  <q-item-section side>{{tags.app.author}}</q-item-section>
  <q-item-section>{{app.author}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.app.type}}</q-item-section>
  <q-item-section>{{tags.serviceTypes[app.type].label}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.app.ver}}</q-item-section>
  <q-item-section>{{app.ver}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.app.level}}</q-item-section>
  <q-item-section>{{app.level}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.app.recentUpd}}</q-item-section>
  <q-item-section>{{app.recentUpd}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.app.installs}}</q-item-section>
  <q-item-section>{{app.installs}}</q-item-section>
 </q-item>
 <q-item>
  <q-item-section side>{{tags.app.cmt}}</q-item-section>
  <q-item-section>{{app.cmt}}</q-item-section>
 </q-item>
</q-list>

<q-banner dense inline-actions class="q-mb-md text-dark bg-blue-grey-1">
{{tags.vers}}
  <template v-slot:action>
    <q-icon name="add_circle" color="primary" @click="open_crt_ver"></q-icon>
  </template>
</q-banner>
<q-markup-table flat dense>
  <thead>
	<tr>
	  <th class="text-left">{{tags.app.ver}}</th>
	  <th class="text-right">{{tags.ver.minCVer}}</th>
	  <th class="text-right">{{tags.ver.size}}</th>
	  <th class="text-right">{{tags.ver.digest}}</th>
	  <th class="text-right"></th>
	</tr>
  </thead>
  <tbody>
	<tr v-for="v in vers">
	 <td class="text-left" @click="service.jumpTo('/ver?service='+id+'&ver='+v.ver)">
	  <q-list flat dense>
       <q-item>
        <q-item-section>
          <q-item-label>{{v.sVer}}</q-item-label>
          <q-item-label caption>{{v.cmt}}</q-item-label>
        </q-item-section>
       </q-item>
	  </q-list>
	 </td>
	 <td class="text-right">{{v.minCVer}}</td>
	 <td class="text-right">{{v.size}}</td>
	 <td class="text-right">{{v.digest}}</td>
	 <td class="text-right"><q-icon name="delete" @click="rmv_ver(v.ver)" color="red" size="2em" v-if="app.power=='O'"></q-icon></td>
	</tr>
  </tbody>
</q-markup-table>

    </q-page>
  </q-page-container>
</q-layout>

<!-- 新建版本弹窗 -->
<q-dialog v-model="newVer.dlg">
  <q-card style="min-width:70vw">
    <q-card-section>
      <div class="text-h6">{{tags.addVer}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
     <q-input v-model="newVer.ver" :label="tags.app.ver" dense
	 :rules="[v=>/^\\d{1,3}(\\.\\d{1,3}){2}$/.test(v) || tags.verPls]"></q-input>
	 <q-input v-model="newVer.minCVer" :label="tags.ver.minCVer" dense
     :rules="[v=>/^\\d{1,3}(\\.\\d{1,3}){2}$/.test(v) || tags.verPls]"></q-input>
     <q-input v-model="newVer.size" :label="tags.ver.size" dense type="number"></q-input>
     <q-input v-model="newVer.digest" :label="tags.ver.digest" dense></q-input>
     <q-input v-model="newVer.cmt" :label="tags.ver.cmt" dense type="textarea"></q-input>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn flat :label="tags.ok" color="primary" @click="add_ver"></q-btn>
      <q-btn flat :label="tags.close" color="primary" v-close-popup></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>

<!-- 请求统计弹窗 -->
<q-dialog v-model="stats.dlg" no-backdrop-dismiss @show="showStats">
  <q-card style="min-width:80vw;">
    <q-card-section class="row items-center q-pb-none">
      <div class="text-h6">{{tags.stats.requests}}</div>
	  <q-space></q-space>
	  <q-btn icon="event" flat>
        <q-popup-proxy cover transition-show="scale" transition-hide="scale">
          <q-date v-model="stats.proxyDate" range>
            <div class="row items-center justify-end">
              <q-btn :label="tags.ok" color="primary" @click="statsDateChanged" v-close-popup></q-btn>
              <q-btn :label="tags.close" color="primary" flat v-close-popup></q-btn>
            </div>
          </q-date>
        </q-popup-proxy>
		{{stats.date.from}} => {{stats.date.to}}
	  </q-btn>
	  <q-space></q-space>
      <q-btn icon="close" flat round dense v-close-popup></q-btn>
    </q-card-section>
    <q-card-section class="q-pt-none">
	 <div id="stats_chart" style="width:78vw;height:70vh;"></div>
    </q-card-section>
  </q-card>
</q-dialog>

<component-alert-dialog :title="tags.failToCall" :errMsgs="tags.errMsgs" :close="tags.close" ref="errMsg"></component-alert-dialog>
`
}