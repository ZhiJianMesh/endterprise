const KEY_NAME="codecase_rootKey";
export default {
inject:['service', 'tags'],
created(){
    this.rootKey=Secure.readItem(KEY_NAME);
    if(this.rootKey != '') {
		this.dlgRoot.crt=false;
		if(this.rootPwd != '' && this.testRootKey(this.rootKey, this.rootPwd)){
			return;
		}
    } else {
		this.dlgRoot.crt=true;
	}
	this.dlgRoot.v=true;
	this.dlgRoot.rootPwd='';
	this.dlgRoot.cfmRootPwd='';
},
data() {return {
    rootKey:'',
    rootPwd:'',
    keys:[],
    dlgRoot:{v:false,v1:false,rootPwd:'',cfmRootPwd:'',crt:false,hide:true},
    dlgPwd:{v:false,name:'',oldName:'',pwd:''},
    page:{cur:1, max:0}
}},
methods:{
rootKeyOpr() {
	if(this.dlgRoot.crt) {
		this.createRootKey();
    } else {
        this.reloadRootKey();
    }
},
createRootKey() {
    if(this.dlgRoot.rootPwd!=this.dlgRoot.cfmRootPwd) {
        this.$refs.errMsg.show(this.tags.mustBeEquals);
        return;
    }
	if(!Secure.isPwdStrong("ddd",this.dlgRoot.rootPwd,6,3,5)) {
        this.$refs.errMsg.show(this.tags.pwdNotStrong);
		return;
	}
    var rootKey=Secure.keyPair(this.dlgRoot.rootPwd);
    var opts={method:"POST",url:"/api/createRootKey",data:{"rootkey":rootKey},cloud:true};
    request(opts, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
			return;
        }
		this.rootKey = rootKey;
		this.rootPwd = this.dlgRoot.rootPwd;
		Secure.saveItem(KEY_NAME, rootKey);//记录在本地
		this.dlgRoot.v = false;
		this.$refs.errMsg.show(this.tags.rpAlert);
    })
},
reloadRootKey() {
	if(this.rootKey!='') { //本地已有，先尝试本地的
		if(this.testRootKey(this.rootKey, this.dlgRoot.rootPwd)) {
			this.rootPwd = this.dlgRoot.rootPwd;
			this.dlgRoot.v = false;
			this.query_keys(1);
		} else {
			this.$refs.errMsg.show(this.tags.invalidRootKey);
		}
		return;
	}
    request({method:"GET",url:"/api/getRootKey",cloud:true}, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
			return;
        }
		this.rootKey=resp.data.rootkey; //不管是否能通过测试，都保存，如果通不过，则输密码重试
		Secure.saveItem(KEY_NAME, resp.data.rootkey);
		if(this.testRootKey(resp.data.rootkey, this.dlgRoot.rootPwd)) {
			this.rootPwd=this.dlgRoot.rootPwd;
			this.dlgRoot.v=false;
			this.query_keys(1);
		} else {
			this.$refs.errMsg.show(this.tags.invalidRootKey);
		}
    })
},
showChgRootPwdDlg() {
	this.dlgRoot.v1=true;
	this.dlgRoot.rootPwd='';
	this.dlgRoot.cfmRootPwd='';
},
changeRootKeyPwd() { //更改根密钥密码，必须是解开之后
    if(this.dlgRoot.rootPwd!=this.dlgRoot.cfmRootPwd) {
        this.$refs.errMsg.show(this.tags.mustBeEquals);
        return;
    }
	
	if(!Secure.isPwdStrong("ddd",this.dlgRoot.rootPwd,6,3,5)) {
        this.$refs.errMsg.show(this.tags.pwdNotStrong);
		return;
	}
	var newRootKey=Secure.changeKeyPairPwd(this.rootKey, this.rootPwd, this.dlgRoot.rootPwd);
	if(newRootKey=='') {
        this.$refs.errMsg.show(this.tags.pwdNotStrong);
		return;
	}
	
	var opts={method:"POST",url:"/api/saveRootKey",data:{"rootkey":newRootKey},cloud:true};
    request(opts, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
			return;
        }
		this.rootKey = newRootKey;
		this.rootPwd = this.dlgRoot.rootPwd;
		Secure.saveItem(KEY_NAME, newRootKey);//记录在本地
		this.dlgRoot.v1 = false;
		this.$refs.errMsg.show(this.tags.rpAlert);
    })
},
query_keys(pg) {
    var offset=(parseInt(pg)-1)*this.service.N_PAGE;
    var url="/api/keys?offset="+offset+"&num="+this.service.N_PAGE;
    request({method:"GET",url:url,cloud:true}, this.service.name).then(resp=>{
        if(resp.code!=RetCode.OK||resp.data.total==0) {
            this.keys=[];
            this.page.max=0;
            this.page.cur=1;
            return;
        }
        this.keys=resp.data.keys;
        this.page.max=Math.ceil(resp.data.total/this.service.N_PAGE);
    });
},
removePwd() {
    this.$refs.confirmDlg.show(this.tags.cfmToDel, ()=>{
        var url="/api/removeKey?name=" + this.dlgPwd.name;
        request({method:"DELETE", url:url,cloud:true}, this.service.name).then(resp=>{
            if(resp.code != RetCode.OK) {
                this.$refs.errMsg.showErr(resp.code, resp.info);
				return;
            }
			this.dlgPwd.v=false;
			if(this.keys.length==1 && this.page.cur>1) {//最后一页只有一个，向前移动一页
				this.query_keys(this.page.cur - 1);
			} else {
				this.query_keys(this.page.cur);
			}
        });
    });
},
savePwd() {
    var encryptedPwd=Secure.keyPairEncrypt(this.rootKey, this.dlgPwd.pwd);
	var reqDta={
		name:this.dlgPwd.name,
		oldName:this.dlgPwd.oldName==''?this.dlgPwd.name:this.dlgPwd.oldName,
		pwd:encryptedPwd
	}
    var opts={method:"POST",url:"/api/saveKey",data:reqDta,cloud:true};
    request(opts, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errMsg.showErr(resp.code, resp.info);
        }else{
			this.dlgPwd.v=false;
            this.query_keys(this.page.cur);
        }
    });
},
showDtl(i) {
	if(i>=0) {
		this.dlgPwd.oldName=this.keys[i].name;
		this.dlgPwd.name=this.keys[i].name;
		this.dlgPwd.pwd=Secure.keyPairDecrypt(this.rootKey,this.rootPwd,this.keys[i].pwd);
	} else {
		this.dlgPwd.name='';
		this.dlgPwd.oldName='';
		this.dlgPwd.pwd='';
	}
	this.dlgPwd.v=true;
	
},
testRootKey(rootKey,rootPwd) {
    var s="testABC";
    try {
        var s1=Secure.keyPairEncrypt(rootKey, s);
        var s2=Secure.keyPairDecrypt(rootKey, rootPwd, s1);
        return s==s2;
    }catch(err) {
        Console.error(err.message);
        return false;
    }
}
},
template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;">
  <q-header class="bg-grey-1 text-primary">
    <q-toolbar>
      <q-avatar square><img src="./favicon.png"></q-avatar>
      <q-toolbar-title>{{tags.app_name}}</q-toolbar-title>
      <q-space></q-space>
	  <q-btn flat dense color="primary" icon="control_point" :label="tags.add" @click="showDtl(-1)"></q-btn>
	  <q-btn flat dense color="primary" icon="lock_reset" :label="tags.chgRootPwd" @click="showChgRootPwdDlg"></q-btn>
    </q-toolbar>
  </q-header>
  <q-page-container>
    <q-page class="q-pa-md">
<div class="q-pa-sm flex flex-center" v-if="page.max>1">
 <q-pagination v-model="page.cur" color="primary" :max="page.max" max-pages="10"
  boundary-numbers="false" @update:model-value="query_keys"></q-pagination>
</div>

<q-list separator>
  <q-item v-for="(k,i) in keys">
   <q-item-section @click="showDtl(i)">{{k.name}}</q-item-section>
  </q-item>
</q-list>
    </q-page>
  </q-page-container>
</q-layout>

<!-- 修改或增加私密信息 -->
<q-dialog v-model="dlgPwd.v" no-backdrop-dismiss>
  <q-card style="min-width:70vw">
    <q-card-section>
      <div class="text-h6">{{dlgPwd.oldName}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
	   <q-input dense v-model="dlgPwd.name" autofocus type="text" :label="tags.name"></q-input>
    </q-card-section>
    <q-card-section class="q-pt-none">
      <q-input dense v-model="dlgPwd.pwd" autofocus type="text" :label="tags.pwd"></q-input>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn :label="tags.ok" color="primary" @click="savePwd"></q-btn>
      <q-btn flat :label="tags.remove" @click="removePwd" v-show="dlgPwd.oldName!=''"></q-btn>
      <q-btn flat :label="tags.close" v-close-popup></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>


<!-- 创建或加载根密钥 -->
<q-dialog v-model="dlgRoot.v" no-backdrop-dismiss>
  <q-card style="min-width:70vw">
    <q-card-section>
      <div class="text-h6">{{tags.noRootKey}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
      <q-input dense v-model="dlgRoot.rootPwd" autofocus
       :type="dlgRoot.hide?'password':'text'" :label="tags.rootPwd">
        <template v-slot:append>
          <q-icon :name="dlgRoot.hide ? 'visibility_off':'visibility'"
            class="cursor-pointer" @click="dlgRoot.hide=!dlgRoot.hide"></q-icon>
        </template>
      </q-input>
      <q-input dense v-model="dlgRoot.cfmRootPwd" autofocus v-show="dlgRoot.crt"
       :type="dlgRoot.hide?'password':'text'" :label="tags.cfmRootPwd">
        <template v-slot:append>
          <q-icon :name="dlgRoot.hide ? 'visibility_off':'visibility'"
            class="cursor-pointer" @click="dlgRoot.hide=!dlgRoot.hide"></q-icon>
        </template>
      </q-input>
      <div>
        <q-checkbox v-model="dlgRoot.crt" :label="tags.crtNewRoot"></q-checkbox>
      </div>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn :label="tags.ok" color="primary" @click="rootKeyOpr()"></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>

<!-- 修改根密钥密码 -->
<q-dialog v-model="dlgRoot.v1" no-backdrop-dismiss>
  <q-card style="min-width:70vw">
    <q-card-section>
      <div class="text-h6">{{tags.chgRootPwd}}</div>
    </q-card-section>
    <q-card-section class="q-pt-none">
      <q-input dense v-model="dlgRoot.rootPwd" autofocus
       :type="dlgRoot.hide?'password':'text'" :label="tags.rootPwd">
        <template v-slot:append>
          <q-icon :name="dlgRoot.hide ? 'visibility_off':'visibility'"
            class="cursor-pointer" @click="dlgRoot.hide=!dlgRoot.hide"></q-icon>
        </template>
      </q-input>
      <q-input dense v-model="dlgRoot.cfmRootPwd" autofocus
       :type="dlgRoot.hide?'password':'text'" :label="tags.cfmRootPwd">
        <template v-slot:append>
          <q-icon :name="dlgRoot.hide ? 'visibility_off':'visibility'"
            class="cursor-pointer" @click="dlgRoot.hide=!dlgRoot.hide"></q-icon>
        </template>
      </q-input>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn :label="tags.ok" color="primary" @click="changeRootKeyPwd()"></q-btn>
      <q-btn flat :label="tags.close" v-close-popup></q-btn>
    </q-card-actions>
  </q-card>
</q-dialog>

<component-alert-dialog :title="tags.failToCall" :errMsgs="tags.errMsgs" :close="tags.close" ref="errMsg"></component-alert-dialog>
<component-confirm-dialog :title="tags.alert" :close="tags.cancel" :ok="tags.ok" ref="confirmDlg"></component-confirm-dialog>
`}