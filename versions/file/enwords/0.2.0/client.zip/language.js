export default {
en:{
  ok:"OK",
  cancel:"Cancel",
  app_name:"English study",

  kn_phonics:"Phonics",
  kn_phonetic:"Phonetic Symbol",
  kn_articles:"Articles",
  phonetictest:"Phonetic Training"
},
cn:{
  app_name:"简词",
  ok:"确定",
  cancel:"取消",
  close:"关闭",
  errMsgs:{
      100001:"本地数据库异常"
  },
  failToCall:"调用失败",
  kn_phonics:"自然拼读",
  kn_phonetic:"音标",
  kn_articles:"课文",
  phonetictest:"音标训练",
  search:"查询",
  wordstest:"背单词",
  stem:{label:"词根",desc:"决定单词的基本含义"},
  prefix:{label:"前缀",desc:"改变单词的含义"},
  suffix:{label:"后缀",desc:"决定单词的词性"},
  levels:{"4":"四级", "6":"六级", "7":"PETS5", "8":"雅思"},
  quote:"单词引用数",
  freq:"出现次数",
  score:"得分",
  known:"已认识",
  unknown:"不认识"
}
};
