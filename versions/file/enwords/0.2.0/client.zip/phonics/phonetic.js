import Symbols from "./data/symbols.js"

export default {
inject:['service', 'tags'],
data() {return {
  symbols:Symbols.list,
  player:new Audio(),
  imgStyle:{
    width:'',
    height:'',
  }
}},
created(){
    var w;
    if(document.body.clientWidth>window.screen.height) {
        w=(90/6)+'vw';
    }else{
        w=(90/4)+'vw';
    }
    this.imgStyle.width=w;
    this.imgStyle.height=w;
},
methods: {
sound(i) {
    var s=this.symbols[i];
    this.player.src = s[0]; //声音
    this.player.play();
}
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.kn_phonetic}}</q-toolbar-title>
      <q-btn flat round icon="playlist_add_check" dense @click="service.jumpTo('/phonics/test')"></q-btn>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">

<div v-for="(s,i) in symbols" @click="sound(i)" class="float-left">
<img :style="imgStyle" :src="s[1]">
</div>

  </q-page>
  </q-page-container>
</q-layout>
`
}