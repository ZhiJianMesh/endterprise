import Symbols from "./data/symbols.js"

export default {
inject:['service', 'tags'],
data() {return {
  symbols:Symbols.list,
  player:new Audio(),
  list:Symbols
}},
methods: {
sound(i) {
    var s=this.symbols[i];
    this.player.src=s[0]; //声音
    this.player.play();
}
},
template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>英语音标分类</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">
<p class="pgp">英语国际音标一共有48个，分为元音和辅音。
元音根据读音长短分为长元音和短元音，同时又可以音节数分为单元音与双元音。辅音分为清辅音和浊辅音。</p>
<p class="pgp">一、元音：</p>
<q-list>
<q-item>
 <q-item-section>
  <q-item-label>单元音</q-item-label>
  <q-item-label>
    <q-chip color="deep-orange" text-color="white" clickable
     v-for="i in list.sgl" @click="sound(i)">{{i}}</q-chip>
  </q-item-label>
 </q-item-section>
</q-item>
<q-item>
 <q-item-section>
  <q-item-label>双元音</q-item-label>
  <q-item-label>
    <q-chip color="primary" text-color="white" clickable
     v-for="i in list.dbl" @click="sound(i)">{{i}}</q-chip>
  </q-item-label>
 </q-item-section>
</q-item>
<q-item>
 <q-item-section>
  <q-item-label>长元音</q-item-label>
  <q-item-label>
    <q-chip color="red" text-color="white" clickable
     v-for="i in list.lng" @click="sound(i)">{{i}}</q-chip>
  </q-item-label>
 </q-item-section>
</q-item>
<q-item>
 <q-item-section>
  <q-item-label>短元音</q-item-label>
  <q-item-label>
    <q-chip color="teal" text-color="white" clickable
     v-for="i in list.shrt" @click="sound(i)">{{i}}</q-chip>
  </q-item-label>
 </q-item-section>
</q-item>
</q-list>

<p class="pgp">二、辅音：</p>
<q-list>
<q-item>
 <q-item-section>
  <q-item-label>清辅音即不震动声带的音标</q-item-label>
  <q-item-label>
    <q-chip color="deep-orange" text-color="white" clickable
     v-for="i in list.vlc" @click="sound(i)">{{i}}</q-chip>
  </q-item-label>
 </q-item-section>
</q-item>
<q-item>
 <q-item-section>
  <q-item-label>浊辅音即会引起声带震动的音标</q-item-label>
  <q-item-label>
    <q-chip color="primary" text-color="white" clickable
     v-for="i in list.vc" @click="sound(i)">{{i}}</q-chip>
  </q-item-label>
 </q-item-section>
</q-item>
</q-list>
  </q-page>
  </q-page-container>
</q-layout>
`}