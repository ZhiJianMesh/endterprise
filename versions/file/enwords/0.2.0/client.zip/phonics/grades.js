export default {
inject:['service', 'tags'],
template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>英语自然拼读六个等级</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">
<q-list>
  <q-item>
    <q-item-section>
      <q-item-label class="text-subtitle1">第一阶</q-item-label>
      <q-item-label>建立字母与字母自然发音之间的直接联系</q-item-label>
    </q-item-section>
  </q-item>
  <q-item>
    <q-item-section>
      <q-item-label class="text-h6">第二阶</q-item-label>
      <q-item-label class="text-subtitle1">能够成功拼读元音+辅音（辅音+元音）</q-item-label>
      <q-item-label caption>如：c-a ca a-t at</q-item-label>
    </q-item-section>
  </q-item>
  <q-item>
    <q-item-section>
      <q-item-label class="text-h5">第三阶</q-item-label>
      <q-item-label class="text-h6">能够成功拼读辅音+元音+辅音</q-item-label>
      <q-item-label caption>如d-o-g dog</q-item-label>
    </q-item-section>
  </q-item>
  <q-item>
    <q-item-section>
      <q-item-label class="text-h4">第四阶</q-item-label>
      <q-item-label class="text-h6">能够成功拼读双音节或多音节单词</q-item-label>
      <q-item-label caption>如sw-ea-t-er sweater</q-item-label>
    </q-item-section>
  </q-item>
  <q-item>
    <q-item-section>
      <q-item-label class="text-h3">第五阶</q-item-label>
      <q-item-label class="text-h6">能够听音辨词，即听到单词读音就能拼出该单词</q-item-label>
    </q-item-section>
  </q-item>
  <q-item>
    <q-item-section>
      <q-item-label class="text-h2">第六阶</q-item-label>
      <q-item-label class="text-h6">单词量大量扩充，能够阅读英语文章</q-item-label>
    </q-item-section>
  </q-item>
</q-list>
  </q-page>
  </q-page-container>
</q-layout>
`
}