import Symbols from "./data/symbols.js"
const SCORES="enwords_phonetic_scores";

export default {
inject:['service', 'tags'],
data() {return {
  symbols:Symbols.list,
  list:[], //音标数组
  rightSym:'', //当前播报的正确选项
  rightTimes:0,
  wrongTimes:0,
  totalScore:0,
  scores:{},
  rightNo:0,
  img0:'', //不能用数组
  img1:'',
  img2:'',
  img3:'',
  minScore:Number.MAX_VALUE,
  player:new Audio(),
  beep:new Audio("/assets/sounds/beep.mp3"),
  imgStyle:{
    width:'',
    height:'',
  }
}},
created(){
    var w;
    if(document.body.clientWidth>window.screen.height) {
        var size=60/2;
        w=size+'vh';
    }else{
        var size=80/2;
        w=size+'vw';
    }
    this.imgStyle.width=w;
    this.imgStyle.height=w;
    this.scores = JSON.parse(storageGet(SCORES, "{}"));
    for(var i in this.symbols) {
        if(!this.scores[i]) { //不存在，则置零
            this.scores[i]={
                r:0, //正确次数
                w:0, //错误次数
                s:0, //得分
                i:i //序号
            };
        }
        this.list.push(i);
    }
    this.ask();
},
unmounted(){
    storageSet(SCORES, JSON.stringify(this.scores));
},
methods: {
answer(no) {
    var chked=this.scores[this.rightSym];
    if(no == this.rightNo) {
        this.rightTimes++;
        this.totalScore++;
        chked.r++;
        chked.s++;
        this.ask();
    } else {
        this.wrongTimes++;
        if(this.totalScore>0) {
            this.totalScore--;
        }
        chked.w++;
        chked.s--;
        this.beep.play();
    }
},
ask() {
    var no=0;
    var min=Number.MAX_VALUE;
    for(var k in this.scores) { //寻找得分最低的
        var sc=this.scores[k];
        if(sc.s<min) {
            no=sc.i;
            this.rightSym=k;
            min=sc.s;
        }
    }
    this.rightNo=Math.floor(Math.random()*4); //正确选项的编号
    var chkedSym=this.symbols[no];
    //如果正确选择在后面，随机选择时又一次选到正确选项，则会重复
    var opts=[{pic:'',i:''},{pic:'',i:''},{pic:'',i:''},{pic:'',i:''}];
    var chked = opts[this.rightNo];
    chked.pic = chkedSym[1];//图像
    chked.i = no; 

    var l=this.list.length;
    var i;
    var opt;
    var isOk=true;
    for(var j=0;j<4;j++) {
        if(j==this.rightNo) {
            continue;
        }
        while(true){
            i = Math.floor(Math.random()*l);
            opt = this.list[i];
            isOk=true;
            for(var k=0;k<4;k++) {
                if(opts[k].i==opt) {
                    isOk=false;
                    break;
                }
            }
            if(isOk) { //选项已存在，则重新选择
                break;
            }
        }
        opts[j]={pic:this.symbols[opt][1],i:opt};
    }
    this.img0=opts[0].pic;
    this.img1=opts[1].pic;
    this.img2=opts[2].pic;
    this.img3=opts[3].pic;
    this.player.src = chkedSym[0]; //声音
    this.player.play();
},
replay(){
    this.player.play();
}
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.phonetictest}}</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">
<div class="q-py-sm" style="text-align:center">
  <q-chip color="amber" text-color="white" icon="military_tech" :label="totalScore"></q-chip>
  <q-chip color="green" text-color="white" icon="beenhere" :label="rightTimes"></q-chip>
  <q-chip color="red" text-color="white" icon="clear" :label="wrongTimes"></q-chip>
  <q-btn round color="primary" text-color="white" icon="replay" @click="replay" size="0.8em" dense></q-btn>
</div>

<table border="0" align="center">
<tr><td @click="answer(0)"><img :style="imgStyle" :src="img0"></td>
<td @click="answer(1)"><img :style="imgStyle" :src="img1"></td></tr>
<tr><td @click="answer(2)"><img :style="imgStyle" :src="img2"></td>
<td @click="answer(3)"><img :style="imgStyle" :src="img3"></td></tr>
</table>
  </q-page>
  </q-page-container>
</q-layout>
`
}