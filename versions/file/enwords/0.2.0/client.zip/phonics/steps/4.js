import Step4Data from '../data/step4.js'

export default {
inject:['service'],
data(){return {
  etymon:Step4Data,
  player:new Audio()
}},
methods: {
    read(w) {
        readText(w[0],act=>{
            console.info(act+":" + w[0]+","+w[1]);
        });
    }
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>步骤四：辅音的混合</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">

<p class="text-h6">1、双辅音</p>
<p class="pgp">双辅音在单词中只发一个音(短音节)；</p>
<p class="pgp">比如：egg[鸡蛋]、odd[奇数]、glass[玻璃]、apple、jazz[爵士乐]</p>
<p class="pgp">特殊情况：/l/和/n/在元音后面只发后半段音；</p>
<p class="pgp">比如：call[呼叫]、bell[铃]、ten[十个]</p>
<p class="text-h6">2、混合辅音(Consonant blends)</p>
<p class="pgp">混合辅音在单词中只发一个音(短音节)。重要的混合辅音为14组。</p>
<q-markup-table bordered dense wrap-cells separator="cell">
 <thead><tr><th>组合</th><th>规则</th><th>举例</th></tr></thead>
 <tbody>
    <tr><td>ck</td><td>/k/</td><td>
        <div v-for="i in etymon.ck" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ng</td><td>/ŋ/</td><td>
        <div v-for="i in etymon.ng" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>tr</td><td>/tr/</td><td>
        <div v-for="i in etymon.tr" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>dr</td><td>/dr/</td><td>
        <div v-for="i in etymon.dr" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>sh</td><td>/ʃ/</td><td>
        <div v-for="i in etymon.sh" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ch</td><td>/tʃ/</td><td>
        <div v-for="i in etymon.ch" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
        <div class="q-pr-none">例外（读/k/）：</div>
        <div v-for="i in etymon.ch_e" @click="read(i)" style="color:red">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>tch（t不发音）</td><td>/tʃ/</td></td><td>
        <div v-for="i in etymon.tch" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td rowspan="2">th</td><td>/θ/<div>在实词的开头或词尾发清辅音θ</div></td><td>
        <div v-for="i in etymon.th_1" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>/ð/<div>在虚词、代词和/er/前发浊辅音ð</div></td><td>
        <div v-for="i in etymon.th_2" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>wh</td><td>/w/</td><td>
        <div v-for="i in etymon.wh" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
        <div class="q-pr-none">例外（读/h/）：</div>
        <div v-for="i in etymon.wh_e" @click="read(i)" style="color:red">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ph、gh</td><td>/f/</td><td>
        <div v-for="i in etymon.ph_gh" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>wr<div>只有一个字母发音</div></td><td>/r/</td><td>
        <div v-for="i in etymon.wr" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td >kn<div>只有一个字母发音</div></td><td>/n/</td><td>
        <div v-for="i in etymon.kn" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>mb<div>只有一个字母发音</div></td><td>/m/</td><td>
        <div v-for="i in etymon.mb" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
 </tbody>
</q-markup-table>
<p class="text-h6">3、辅音连缀</p>
<p class="pgp">重要的辅音连缀为5对、7组/s.../。</p>
<q-markup-table bordered dense wrap-cells separator="cell">
 <thead><tr><th>组合</th><th>规则</th><th>举例</th></tr></thead>
 <tbody>
    <tr><td>br、bl</td><td>/br/,/bl/</td><td>
        <div v-for="i in etymon.br_bl" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>cr、cl</td><td>/kr/,/kl/</td><td>
        <div v-for="i in etymon.cr_cl" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>fr、fl</td><td>/fr/,/fl/</td><td>
        <div v-for="i in etymon.fr_fl" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>gr、gl</td><td>/gr/,/gl/</td><td>
        <div v-for="i in etymon.gr_gl" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>pr、pl</td><td>/pr/,/pl/</td><td>
        <div v-for="i in etymon.pr_pl" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>sl</td><td>/sl/</td><td>
        <div v-for="i in etymon.sl" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>sw</td><td>/sw/</td><td>
        <div v-for="i in etymon.sw" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>sm</td><td>/sm/</td><td>
        <div v-for="i in etymon.sm" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>sn</td><td>/sn/</td><td>
        <div v-for="i in etymon.sn" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>sp</td><td>转音/sb/</td><td>
        <div v-for="i in etymon.sp" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>st</td><td>转音/sd/</td><td>
        <div v-for="i in etymon.st" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>sc、sk</td><td>转音/sg/</td><td>
        <div v-for="i in etymon.sc_sk" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
 </tbody>
</q-markup-table>

  </q-page>
  </q-page-container>
</q-layout>
`
}