import Step5Data from '../data/step5.js'

export default {
inject:['service'],
data(){return {
  etymon:Step5Data,
  player:new Audio()
}},
methods: {
    read(w) {
        readText(w[0],act=>{
            console.info(act+":" + w[0]+","+w[1]);
        });
    }
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>步骤五：特殊拼读组合</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">

<q-markup-table bordered dense wrap-cells separator="cell">
<thead><tr><th>分类</th><th>组合</th><th>规则</th><th>举例</th></tr></thead>
<tbody>
<tr><td rowspan="4">c、g、y的特殊发音</td><td>y</td><td>/j/</td><td>
    <div v-for="i in etymon.y" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>soft c</td><td>在字母i、y、e前，读变音/s/</td><td>
    <div v-for="i in etymon.soft_c" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>soft g</td><td>在字母i、y、e前，读变音/dʒ/</td><td>
    <div v-for="i in etymon.soft_g" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    <div class="q-pr-none">例外（读/g/）：</div>
    <div v-for="i in etymon.wh_e" @click="read(i)" style="color:red">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>hard c、g</td><td>除上述情况外，读/k/、/g/</td><td>
    <div v-for="i in etymon.hard_cg" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>

<tr><td rowspan="2">字母/oo/组合</td><td>在以爆破音结尾的单词中</td><td>/u/</td><td>
    <div v-for="i in etymon.oo_1" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>除上述情况外</td><td>/u:/</td><td>
    <div v-for="i in etymon.oo_2" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>

<tr><td rowspan="7">元音+r 组合</td><td>ar</td><td>/a:/</td><td>
    <div v-for="i in etymon.ar" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>er 在单词末尾</td><td>/ə/</td><td>
    <div v-for="i in etymon.er_1" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>er 在单词中间</td><td>/ɜ:/</td><td>
    <div v-for="i in etymon.er_2" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>ir</td><td>/ɜ:/</td><td>
    <div v-for="i in etymon.ir" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>ur</td><td>/ɜ:/</td><td>
    <div v-for="i in etymon.ur" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>or</td><td>/ɜ:/</td><td>
    <div v-for="i in etymon.or_1" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>or</td><td>有时读/ɔ:/</td><td>
    <div v-for="i in etymon.or_2" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>

<tr><td rowspan="7">双元音</td><td>ow 通常在单词末尾或开头</td><td>/əʊ/</td><td>
    <div v-for="i in etymon.ow_1" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>ow 通常在单词中间或末尾</td><td>/au/</td><td>
    <div v-for="i in etymon.ow_2" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>ou</td><td>/au/</td><td>
    <div v-for="i in etymon.ou" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>oi 在字母/l/和/n/前</td><td>/ɔi/</td><td>
    <div v-for="i in etymon.oi" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>oy 在单词末尾</td><td>/ɔi/</td><td>
    <div v-for="i in etymon.oy" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>au</td><td>/ɔ:/</td><td>
    <div v-for="i in etymon.au" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>aw</td><td>/ɔ:/</td><td>
    <div v-for="i in etymon.aw" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>

<tr><td rowspan="2">字母qu、que的组合</td><td>qu 在单词开头</td><td>/kw/</td><td>
    <div v-for="i in etymon.qu_1" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
<tr><td>que 在单词末尾</td><td>/k/</td><td>
    <div v-for="i in etymon.qu_2" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
</td></tr>
</tbody>
</q-markup-table>

  </q-page>
  </q-page-container>
</q-layout>
`
}