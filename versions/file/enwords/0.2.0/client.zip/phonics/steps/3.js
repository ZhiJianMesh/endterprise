export default {
inject:['service'],
template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>步骤三：单词的自然拼读规则</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">
<ol>
<li class="text-h6">先找元音及元音组合；</li>
<p class="pgp">比如单词say、warmer、unhappy(短线划出元音及元音组合)；</p>
<li class="text-h6">确定音节，有几个元音或元音组合就有几个音节；</li>
<p class="pgp">比如上述三个单词分别有1、2、3个音节</p>
<li class="text-h6">划分音节，两个元音或元音组合之间，只有一个辅音，辅音归后；</li>
<p class="pgp">比如单词warmer，在两个元音组合之间，只有一个辅音m，这个辅音m归后，即war/mer
两个元音或元音组合之间，有两个辅音，前后各一；比如单词customer，在两个元音/u/和/o/之间，有两个辅音/s/和/t/，前后各一，即cus/to/mer</p>
<li class="text-h6">写出拼读公式，元音或元音组合+最近的辅音+次辅音(主次以前后为准，前主后次)</li>
<p class="pgp">比如单词say，第一步写出元音组合/ay/，第二步加上辅音/s/，即ay->say；</p>
<p class="pgp">比如单词war/mer，第一步写出元音组合/ar/，第二步加上辅音/w/，即ar->war；然后重复以上过程，完成第二个音节，即er->mer；最后将二个音节综合起来，即war+mer->warmer；</p>
<p class="pgp">比如单词cus/to/mer，第一步写出元音/u/，第二步加上最近的辅音/c/，第三步加上次辅音/s/，即u->cu->cus；
    然后重复以上过程，完成第二、第三个音节，即o->to、er->mer；最后将三个音节综合起来，即cus+to+mer->customer</p>
<li class="text-h6">自然拼读，每个过程都是拼读过程</li>
</ol>
  </q-page>
</q-page-container>
</q-layout>
`}