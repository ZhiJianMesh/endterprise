import Step2Data from '../data/step2.js'

export default {
inject:['service'],
data(){return {
  etymon:Step2Data,
  player:new Audio()
}},
methods: {
read(w) {
    readText(w[0]).then(act=>{
        console.info(act+":" + w[0]+","+w[1]);
    });
}
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>步骤二：元音字母音</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">
<p class="pgp">5个元音构成的以下元音组合的发音，就是该元音的字母音，即该字母的读音，但必须是发长音。</p>

<br>
<p class="pgp">1、a的字母音--其组合为a_e、ai、ai，发音为a的字母音，写作/ei/</p>
<q-markup-table bordered dense wrap-cells separator="cell">
<thead><tr><th>组合</th><th>规则</th><th>举例</th></tr></thead>
<tbody>
    <tr><td>a_e</td><td>e在结尾不发音</td><td>
        <div v-for="i in etymon.a_e" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
        <div class="q-pr-none">例外（读/æ/）：</div>
        <div v-for="i in etymon.a_e_e" @click="read(i)" style="color:red">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ai</td><td>出现在n、l结尾的单词中</td><td>
        <div v-for="i in etymon.ai" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ay</td><td>出现在词尾</td><td>
        <div v-for="i in etymon.ay" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
</tbody>
</q-markup-table>

<br>
<p class="pgp">2、e的字母音----其组合为e_e、ee、ea、_e，发音为e的字母音，写作/i:/</p>
<q-markup-table bordered dense wrap-cells separator="cell">
<thead><tr><th>组合</th><th>规则</th><th>举例</th></tr></thead>
<tbody>
    <tr><td>e_e</td><td>结尾的e不发音</td><td>
        <div v-for="i in etymon.e_e" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ee</td><td></td><td>
        <div v-for="i in etymon.ee" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ea</td><td></td><td>
        <div v-for="i in etymon.ea" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>_e</td><td>只有一个元音e，且在词尾</td><td>
        <div v-for="i in etymon._e" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
</tbody>
</q-markup-table>

<br>
<p class="pgp">3、i的字母音----其组合为i_e、ie、igh、_y，发音为i的字母音，写作/ai/</p>
<q-markup-table bordered dense wrap-cells separator="cell">
<thead><tr><th>组合</th><th>规则</th><th>举例</th></tr></thead>
<tbody>
    <tr><td>i_e</td><td>e在结尾不发音</td><td>
        <div v-for="i in etymon.i_e" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>_ie</td><td>出现在词尾</td><td>
        <div v-for="i in etymon._ie" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>igh</td><td>出现在辅音之间且结尾为爆破音</td><td>
        <div v-for="i in etymon.igh" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>_y</td><td>全是辅音且出现在词尾</td><td>
        <div v-for="i in etymon._y" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
</tbody>
</q-markup-table>

<br>
<p class="pgp">4、o的字母音----其组合为o_e、oa、ow，发音为o的字母音，写作/əʊ/</p>
<q-markup-table bordered dense wrap-cells separator="cell">
 <thead><tr><th>组合</th><th>规则</th><th>举例</th></tr></thead>
 <tbody>
    <tr><td>o_e</td><td>e在结尾不发音</td><td>
        <div v-for="i in etymon.o_e" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
        <div class="q-pr-none">例外（读/ʌ/）：</div>
        <div v-for="i in etymon.o_e_e" @click="read(i)" style="color:red">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>oa</td><td>出现在辅音之间且结尾为爆破音</td><td>
        <div v-for="i in etymon.oa" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ow</td><td>出现在词尾</td><td>
        <div v-for="i in etymon._ow" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
        <div class="q-pr-none">例外（读/au/）：</div>
        <div v-for="i in etymon._ow_e" @click="read(i)" style="color:red">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
 </tbody>
</q-markup-table>

<br>
<p class="pgp">5、u的字母音----其组合为u_e、ue、ui，这些组合的发音特别有趣，它有两个发音，即u的(汉语拼音)字母读音/u:/ 或(英文)字母音/ju:/</p>
<q-markup-table bordered dense wrap-cells separator="cell">
 <thead><tr><th>组合</th><th>规则</th><th>举例</th></tr></thead>
 <tbody>
    <tr><td rowspan="2">u_e</td>
     <td>前面为爆破音时读/ju:/</td><td>
      <div v-for="i in etymon.u_e" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr>
     <td>其他情况读/u:/</td><td>
        <div v-for="i in etymon.u_e_o" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td rowspan="2">ue</td><td>前面为爆破音时读/ju:/</td><td>
        <div v-for="i in etymon.ue" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>其他情况，一般在词尾时，读/u:/</td><td>
        <div v-for="i in etymon.ue_o" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
    <tr><td>ui</td><td>前面为爆破音时读/ju:/</td><td>
        <div v-for="i in etymon.ui" @click="read(i)">{{i[0]}}[{{i[1]}}]</div>
    </td></tr>
 </tbody>
</q-markup-table>

<br>
<p class="pgp">6、必要的补充：关于爆破音、摩擦音、清辅音与浊辅音</p>
<p class="pgp">爆破音、摩擦音各6个，其又分为爆破清辅音、爆破浊辅音、摩擦清辅音、摩擦浊辅音。
    关于爆破音与摩擦音一节，很重要，也是初级课程里最难的地方，但学到转音规则仍然会觉得有趣。</p>
<ol>
<li>爆破音--发音器官在口腔中形成阻碍，然后气流冲破阻碍而发出的音</li>
<ul>
<li>p t k  清辅音--有气流、无声音、(声带)无振动</li>
<li>b d g  浊辅音--有气流、有声音、(声带)有振动</li>
</ul>
<li>摩擦音--牙齿合拢，气流从牙齿缝中发出来</li>
<ul>
<li>s f th  清辅音--牙齿中间无舌头，如bath[洗澡]、mouth[嘴巴]、thing[东西]</li>
<li>z v th  浊辅音--牙齿中间有舌头，舌尖略略伸出，放在上下齿之间，轻触上齿，气流从上齿和舌尖之间流出，如the、this、that、thank[感谢]。</li>
</ul>
<li>转音规则--摩擦音s与爆破清辅音p、t、k结合，转发爆破浊辅音b、d、g</li>
<ul>
<li>sp-->sb  spy spill spoon</li>
<li>st-->sd  stay still stone</li>
<li>sk-->sg  sky skill</li>
</ul>
</ol>
  </q-page>
  </q-page-container>
</q-layout>
`}