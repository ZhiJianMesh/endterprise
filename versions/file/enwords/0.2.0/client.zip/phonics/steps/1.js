export default {
inject:['service'],

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>步骤一：26个字母的发音</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">
<p class="pgp">Phonics自然拼音，或叫“英语自然拼读法”更容易理解。拼读什么？就是看到英文字母或字母的组合能自然地读出、读对它的发音。
这里，首先要区分“读音”(Name)与“发音”(Sound)。</p>
<p class="pgp">A-Z的26个字母念出来的就是字母本身的“读音”；自然发音指的是字母的“发音”。
发音不同于读音，看到字母后，不管读音，找对发音，这就是Phonics第一步要学的。
Phonics注重方法与实践，因此，知道怎么正确发音就行了。</p>
<ul>
<li>21个辅音字母的发音</li>
<p>其实只有18个。C/K发音相同，只能算做一个；W、Y是两个半元音字母。</p>
<li>5个元音字母“a、e、i、o、u”的发音是学习的重点。</p>
</ul>
  </q-page>
  </q-page-container>
</q-layout>
`}