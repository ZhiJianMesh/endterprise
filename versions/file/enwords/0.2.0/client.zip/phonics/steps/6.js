export default {
inject:['service'],

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>步骤六：连读规则</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">

<p class="text-h6">1、掌握爆破音、摩擦音及转音规则</p>
<p class="text-h6">2、掌握不完全爆破规则</p>
<p class="pgp">在朗读中，六个爆破音在一定情况下不必爆破出来，就是说气流不必冲破阻碍，而只是发音器官在口腔中形成阻碍，稍作停顿后马上过渡到后面的音，这种现象叫不完全爆破。</p>
<ol type="A" style="font-size:1.2em;">
<li>发生在单词内部</li>
<p class="pgp">比如：bla(ck)board[板]、foo(t)ball、ke(p)t，括号中的辅音字母对应的辅音音素/k/t//p/稍作停顿，没发出音来。</p>
<li>发生在两个相邻单词之间</li>
<ol type="I">
<li>爆破音中的任何两个爆破音相邻时，前一爆破音失去爆破。</li>
<p>比如：a bi(g) car</p>
<li>爆破音后接摩擦音/f/s/th/ch/时，前面的爆破音失去爆破。</li>
<p>比如：I didn'(t) say so.</p>
<li>爆破音后接/t/d/tr/dr /时，前面的爆破音失去爆破。</li>
<p>比如：a grea(t) change[改变]</p>
<li>爆破音后接/m/n/l/时，前面的爆破音失去爆破。</li>
<p>比如：a bi(t) more expensive[昂贵的]</p>
</ol>
</ol>

<p class="text-h6">3、英语连读</p>
<ol type="A" style="font-size:1.2em;">
<li>在同一意群中，前一词以辅音音素结尾，后一词以元音音素开头，在说话或朗读句子时，就要自然地将辅音和元音相拼，构成一个音节读，这种语音现象叫连读。连读时只需顺其自然地一带而过，不可以加音，也不可以读得太重；</li>
<p>比如：We have an English friend[朋友].</p>
<p>这个句子有两处连读：前一处是have的尾辅音/v/与an的开头元音/a/连读为/va/；后一处是an的尾辅音/n/与English的开头音素/i/连读为/ni/。</p>
<li>r连读。在短语或句子中，前一词以-r或-re结尾，后一词以元音开头时，可将/r/与后面的元音拼读；</li>
<p>比如：They looked for it here and there.</p>
<p>这个句子也有两处连读：前一处是for it合读为/frit/，后一处是here and合读为/hirnd/。</p>
<li>连读现象只出现在意群内部，意群与意群之间的相邻单词即使符合上述两个条件，也不连读；</li>
<p>比如：I hope[期望] it'll get a little warmer[温暖].</p>
<p>这个句子中的hope it就不连读为/hupit/，因为主句I hope是一个意群，后面的从句是另一个意群。</p>
<p>又如：There is a book in it.一句中book与in不连读，因为book与in分别在两个不同的意群中。</p>
<li>两个辅音/t/相连，省略第一个/t/；</li>
<p>比如：start[开始] to cry[哭泣] /  hate[讨厌] to fly[飞翔]</p>
<li>英语元音开头要弱读；</li>
<li>英语次辅音，与元音之间隔着一个辅音，要弱读。</li>
</ol>

  </q-page>
  </q-page-container>
</q-layout>
`
}