export default {
inject:['service', 'tags'],
created(){
},
methods: {
    go_to(act) {
        this.service.jumpTo(act);
    }
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.kn_phonics}}</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-lg">
<p class="cursor-pointer">
<p class="text-h6" @click="go_to('/phonics/what')">什么是英语自然拼读法</p>
<p class="text-h6" @click="go_to('/phonics/grades')">英语自然拼读六个等级</p>
<p class="text-h6" @click="go_to('/phonics/classification')">英语音标分类</p>
<p class="text-h6" @click="go_to('/phonics/phonetic')">英语音标发音表</p>
<p class="text-h6" @click="go_to('/phonics/test')">英语音标训练</p>
</p>
<p class="text-h6">自然拼读学习步骤</p>
<ul class="pgp cursor-pointer">
<li class="text-subtitle1" @click="go_to('/phonics/step1')">步骤一：26个字母的发音</li>
<li class="text-subtitle1" @click="go_to('/phonics/step2')">步骤二：元音字母音</li>
<li class="text-subtitle1" @click="go_to('/phonics/step3')">步骤三：单词的自然拼读规则</li>
<li class="text-subtitle1" @click="go_to('/phonics/step4')">步骤四：辅音的混合</li>
<li class="text-subtitle1" @click="go_to('/phonics/step5')">步骤五：特殊拼读组合</li>
<li class="text-subtitle1" @click="go_to('/phonics/step6')">步骤六：连读规则</li>
</ul>
  </q-page>
  </q-page-container>
</q-layout>
`}