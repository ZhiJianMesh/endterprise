import FixesData from './words/data/fixes.js'
const BATCH_NUM=100;
const KNOWN_SCORE=100;
const WORDS_VER="enwords_ver";

export default {
inject:['service', 'tags'],
data(){return{
    fixes:FixesData,
    search:{key:'', type:'stem'},
    words:[],
    page:{max:0,cur:1},
    db:this.service.db
}},
mounted(){
	if(!this.service.wordsChked) {
		this.init();
	}
},
methods:{
init() {
    Database.initialize(this.db, `
        create table if not exists words (
            level    short not null, -- 级别,4:四级，6:六级，7:PETS5，8:雅思
            quote    short not null, -- 在其他词中出现的次数
            freq     int not null,  -- 出现频率
            score    int not null,  -- 正确一次加1，错误一次减1
            word     varchar(255) not null primary key,
            phntc    varchar(255) not null, -- 注音phonetic symbol
            expl     varchar(1024) not null -- 解释
        );
        create index if not exists idx_words_freq on words(freq);
        create index if not exists idx_words_score on words(score);
        create index if not exists idx_words_level on words(level);
		
        create table if not exists config (
            k        varchar(255) not null primary key,
            v        text not null
        );
		insert or ignore into config(k,v) values("words_ver", "1.0.0");
    `).then(res => {
        if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return res;
        }
        var opts={method:"GET", private:false, cloud:true, url:"/words/ver"};
        return request(opts, this.service.name);
    }).then(res => {
        if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return;
        }
		this.dlAllWords(res.data.ver)
    });	
},
queryWords(pg){
    if(this.search.key=='') {
        return;
    }
    var sql = 'select count(*) total from words where word like ';
    if(this.search.type=='stem') {
        sql += `'%`+this.search.key+`%'`
    } else if(this.search.type=='prefix') {
        sql += `'`+this.search.key+`%'`
    } else if(this.search.type=='suffix') {
        sql += `'%`+this.search.key+`'`
    }
    Database.queryMap(this.db, sql).then(res=> {
        if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return;
        }
        if(res.data.total<=0) {
            this.page.max=0;
            this.page.cur=1;
            return;
        }
        this.page.max=Math.ceil(res.data.total/this.service.N_PAGE);
        this.page.cur=pg;
        this.innerQueryWords(pg);
    });
},
innerQueryWords(pg) {
    var sql = 'select word,expl,phntc,quote,level,freq,score from words where word like ';
    if(this.search.type=='stem') {
        sql += `'%`+this.search.key+`%'`
    } else if(this.search.type=='prefix') {
        sql += `'`+this.search.key+`%'`
    } else if(this.search.type=='suffix') {
        sql += `'%`+this.search.key+`'`
    }
    var offset=(pg-1)*this.service.N_PAGE;
    var limit=this.service.N_PAGE;
    sql += ' order by word LIMIT ' + limit + ' OFFSET ' + offset;
    Database.queryMaps(this.db, sql).then(res=> {
        if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return;
        }
        if(!res.data || !res.data.rows) {
            return;
        }
        var words=[];
        var levels=this.tags.levels;
        for(var r of res.data.rows) {
            var known, color;
            if(r.score>=KNOWN_SCORE){
                known=this.tags.known;
                color='primary';
            } else {
                known=this.tags.unknown;
                color='red';
            }

            var word={word:r.word, expl:r.expl, phntc:r.phntc,
                quote:r.quote, freq:r.freq, score:r.score,
                level:levels[r.level], known:known, color:color};
            words.push(word);
        }
        this.words=words;
    })
},
queryPreset(key){ //查询预置的词根词缀
    this.search.key=key;
    this.queryWords(1);
},
clrSearch(){
    this.search.key='';
    this.words=[];
    this.page.max=0;
    //this.page.cur=1; //会触发切换page，导致查询
},
dlAllWords(serverVer) {
	Database.queryMap(this.db, "select v from config where k='words_ver'").then(res => {
		if(res.code == RetCode.OK) {
			if(this.verToInt(res.data.v)>=this.verToInt(serverVer)) {
				//本地是新版本，则需要比较数量
				return Database.queryMap(this.db, "select count(*) total from words");
			}
		}
		return {code:RetCode.OK, data:{total:0}};
	}).then(res => {
	    if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return;
        }
		if(res.data.total==0) {
			this.dlWords(0, serverVer);
		} else {
			this.service.wordsChked=true;
			Console.info("wordsChked setted")
		}
	});
},
dlWords(offset, serverVer) { //下载一个分段
    var opts={
        method:"GET", private:false, cloud:true,
        url:"/words/gets?offset=" + offset + "&num="+BATCH_NUM
    };
    request(opts, this.service.name).then(resp=>{
        if(resp.code != RetCode.OK) {
            this.$refs.errDlg.showErr(resp.code, resp.info);
            return;
        }
        var sqls=[];
        var cols=resp.data.cols;
        var num=resp.data.words.length;
        var w, k, word1, expl1, phntc1;
        for(var word of resp.data.words) {
            w={};
            k=0;
            for(var c of cols) {
                w[c] = word[k++];
            }
            word1 = w.word.replace(/'/g, "''"); 
            expl1 = w.expl.replace(/'/g, "''");
            phntc1 = w.phntc.replace(/'/g, "''");
            sqls.push(`UPDATE words SET expl='` + expl1
                   +`',phntc='` + phntc1 + `',quote=` + w.quote
                   + ',level=' + w.level + ',freq=' + w.freq
                   + " where word='" + word1 + "'"); //先更新，再插入，实现upsert
            sqls.push("insert or ignore into words(word,expl,phntc,quote,level,freq,score) values('"
                   + word1 + `','` + expl1 + `','` + phntc1 + `',`
                   + w.quote + ',' + w.level + ',' + w.freq + ',0)');
        }
        Database.executes(this.db, sqls.join(';')).then(res=> {
            if(res.code != RetCode.OK) {
                this.$refs.errDlg.showErr(res.code, res.info);
                return;
            }
            if(num == BATCH_NUM) {
				//最后一批数量小于BATCH_NUM,如果单词数正好是BATCH_NUM的整数倍，则最后一次为0
                this.dlWords(offset + BATCH_NUM, serverVer);
            } else { //下载完成才更新版本
				Database.execute(this.db, "update config set v='" + serverVer + "' where k='words_ver'");
				this.service.wordsChked=true;
			}
        });
    });
},
read(w) {
    readText(w).then(act=>{
        console.info(act+":" + w);
    });
},
known(i) {
    var score, color, known;
    if(this.words[i].score>=KNOWN_SCORE) {
        score=0;
        color='red';
        known=this.tags.unknown;
    } else {
        score=KNOWN_SCORE;
        color='primary';
        known=this.tags.known;
    }
    var w=this.words[i].word.replace(/'/g, "''");
    var sql="update words set score="+score+" where word='" + w + "'";
    Database.execute(this.db, sql).then(res=> {
        if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return;
        }
        this.words[i].score = score;
        this.words[i].color = color;
        this.words[i].known = known;
    });
},
verToInt(ver) {
    var ss=ver.split(".");
    return parseInt(ss[0])*1000000 + parseInt(ss[1])*1000 + parseInt(ss[2]);
}
},
template:`
<q-layout view="lHh lpr lFf" container style="height:100vh;width:100vw;">
 <q-header>
  <q-toolbar>
    <q-avatar square><img src="./favicon.png"></q-avatar>
    <q-toolbar-title>{{tags.app_name}}</q-toolbar-title>
    <q-btn :label="tags.kn_phonics" @click="service.jumpTo('/phonics')" flat></q-btn>
    <q-btn :label="tags.wordstest" @click="service.jumpTo('/words/test')" flat></q-btn>
  </q-toolbar>
  <div class="q-pa-sm flex flex-center bg-grey-1" v-show="page.max>1">
   <q-pagination v-model="page.cur" color="primary" :max="page.max" max-pages="15"
    boundary-numbers="false" @update:model-value="queryWords"></q-pagination>
  </div>
 </q-header>
 <q-footer class="q-px-md bg-grey-1">
  <q-tabs dense v-model="search.type" class="text-black" active-bg-color="indigo-1" indicator-color="transparent">
   <q-tab name="stem" :label="tags.stem.label"></q-tab>
   <q-tab name="prefix" :label="tags.prefix.label"></q-tab>
   <q-tab name="suffix" :label="tags.suffix.label"></q-tab>
  </q-tabs>
  <q-input outlined bottom-slots v-model="search.key" :label="tags.search" dense @keyup.enter="queryWords(1)">
   <template v-slot:append>
    <q-icon v-if="search.key!==''" name="close" @click="clrSearch" class="cursor-pointer"></q-icon>
    <q-icon name="search" @click="queryWords(1)"></q-icon>
   </template>
  </q-input>
 </q-footer>
 <q-page-container>
   <q-page class="q-pa-md">

<div v-show="page.max>0">
<q-list separator>
 <q-item v-for="(w,i) in words">
  <q-item-section avatar @click="read(w.word)">
   <q-item-label>{{w.word}} </q-item-label>
   <q-item-label caption>[{{w.phntc}}]</q-item-label>
  </q-item-section>
  <q-item-section @click="known(i)">
   <q-item-label>{{w.expl}}</q-item-label>
   <q-item-label caption>
    {{w.level}} {{tags.score}}:{{w.score}}
    <q-chip dense :color="w.color" text-color="white">{{w.known}}</q-chip>
   </q-item-label>
  </q-item-section>
  <q-item-section side>
   <q-item-label caption>{{tags.freq}}:{{w.freq}}</q-item-label>
   <q-item-label caption>{{tags.quote}}:{{w.quote}}</q-item-label>
  </q-item-section>
 </q-item>
</q-list>
</div>
<div v-show="page.max<=0">
 <q-tab-panels v-model="search.type">
    <q-tab-panel name="stem">
      <div class="text-subtitle1">{{tags.stem.desc}}</div>
      <q-list separator>
       <q-item v-for="f in fixes.stem" clickable @click="queryPreset(f[0])">
        <q-item-section>
         <q-item-label>{{f[0]}}</q-item-label>
        </q-item-section>
        <q-item-section>
         <q-item-label caption>{{f[1]}}</q-item-label>
        </q-item-section>
        <q-item-section side>
         <q-item-label caption>{{f[2]}}</q-item-label>
        </q-item-section>
       </q-item>
      </q-list>
    </q-tab-panel>

    <q-tab-panel name="prefix">
      <div class="text-subtitle1">{{tags.prefix.desc}}</div>
      <q-list separator>
       <q-item v-for="f in fixes.prefix" clickable @click="queryPreset(f[0])">
        <q-item-section>
         <q-item-label>{{f[0]}}</q-item-label>
        </q-item-section>
        <q-item-section>
         <q-item-label caption>{{f[1]}}</q-item-label>
        </q-item-section>
        <q-item-section side>
         <q-item-label caption>{{f[2]}}</q-item-label>
        </q-item-section>
       </q-item>
      </q-list>
    </q-tab-panel>

    <q-tab-panel name="suffix">
      <div class="text-subtitle1">{{tags.suffix.desc}}</div>
      <q-list separator>
       <q-item v-for="f in fixes.suffix" clickable @click="queryPreset(f[0])">
        <q-item-section>
         <q-item-label>{{f[0]}}</q-item-label>
        </q-item-section>
        <q-item-section>
         <q-item-label caption>{{f[1]}}</q-item-label>
        </q-item-section>
        <q-item-section side>
         <q-item-label caption>{{f[2]}}</q-item-label>
        </q-item-section>
       </q-item>
      </q-list>
    </q-tab-panel>
 </q-tab-panels>
</div>
    </q-page>
  </q-page-container>
</q-layout>
<component-alert-dialog :title="tags.failToCall" :errMsgs="tags.errMsgs" :close="tags.close" ref="errDlg"></component-alert-dialog>
`}