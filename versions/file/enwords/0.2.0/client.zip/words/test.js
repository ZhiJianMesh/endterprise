export default {
inject:['service', 'tags'],
data() {return {
  word:{word:'', phntc:'', expl:'', level:'', quote:0, freq:0, score:0},
  opts:[{n:'A',opt:{}},{n:'B',opt:{}},{n:'C',opt:{}},{n:'D',opt:{}}],
  level:"6",
  rightNo:0,
  rightTimes:0,
  wrongTimes:0,
  totalScore:0,
  db:this.service.db,
  player:new Audio(),
  beep:new Audio("/assets/sounds/beep.mp3")
}},
created(){
    var sql = 'select sum(score) score from words where score<>0';
    Database.queryMap(this.db, sql).then(res=> {
        if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return;
        }
        this.totalScore=res.data.score;
    })
    this.ask();
},
methods: {
answer(no) {
    var score;
    if(no == this.rightNo) {
        this.rightTimes++;
        this.totalScore++;
        score=1;
    } else {
        this.wrongTimes++;
        if(this.totalScore>0) {
            this.totalScore--;
        }
        score=-1;
        this.beep.play();
    }
    Database.execute(this.db, 'update words set score=score+' + score + ` where word='` + this.word.word + `'`).then(res=> {
        if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return;
        }
        if(score > 0) {
            this.ask();
        }
    });
},
ask() {
    this.rightNo=Math.floor(Math.random()*4); //正确选项的编号
	var askSql = `select word,phntc,expl,quote,freq,level,score from words
                 where level<=` + this.level + ' order by score asc LIMIT 4'; //查询得分最小的四个单词
    Database.queryMaps(this.db, askSql).then(res=> {
        if(res.code != RetCode.OK) {
            this.$refs.errDlg.showErr(res.code, res.info);
            return;
        }
        
        var n = this.rightNo; //第一个是得分最小的，总是以得分最小的为正确选项
        for(var i=0; i<res.data.rows.length; i++) {
            this.opts[n % 4].opt = res.data.rows[i];
            n++;
        }
        this.word=res.data.rows[0];//正确项
    });
},
read(w) {
    readText(w).then(act=>{
        console.info(act+":" + w);
    });
}
},

template: `
<q-layout view="lHh lpr lFf" container style="height:100vh">
  <q-header>
    <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.wordstest}}</q-toolbar-title>
    </q-toolbar>
  </q-header>

  <q-page-container>
  <q-page class="q-pa-md">
<div class="q-py-sm" style="text-align:center">
  <q-chip color="amber" text-color="white" icon="military_tech" :label="totalScore"></q-chip>
  <q-chip color="green" text-color="white" icon="beenhere" :label="rightTimes"></q-chip>
  <q-chip color="red" text-color="white" icon="clear" :label="wrongTimes"></q-chip>
</div>
<div class="q-gutter-sm">
  <q-radio v-for="(n,l) in tags.levels" v-model="level" :val="l" :label="n"></q-radio>
</div>
<div class="q-pa-md">
 <q-list padding>
  <q-item>
   <q-item-section avatar class="text-bold text-h5">{{word.word}}</q-item-section>
   <q-item-section>
    <q-item-label >[{{word.phntc}}]</q-item-label>
    <q-item-label caption>{{tags.levels[word.level]}}</q-item-label>
   </q-item-section>
   <q-item-section side>
   <q-item-label caption>{{tags.freq}}:{{word.freq}}</q-item-label>
   <q-item-label caption>{{tags.quote}}:{{word.quote}}</q-item-label>
   </q-item-section>
  </q-item>
  <q-item v-for="(o,i) in opts" clickable @click="answer(i)">
    <q-item-section avatar>{{o.n}}.</q-item-section>
    <q-item-section>{{o.opt.expl}}</q-item-section>
  </q-item>
 </q-list>
 </div>
  </q-page>
 </q-page-container>
</q-layout>
<component-alert-dialog :title="tags.failToCall" :errMsgs="tags.errMsgs" :close="tags.close" ref="errDlg"></component-alert-dialog>
`
}