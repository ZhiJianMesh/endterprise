export default {
inject:['service', 'tags'],
data() {return {
    beginTime:0,
    days:7,
    pkgId:0,
    mainCharts:null,
    pkgCharts:null,
    date:'',
    dateStr:'',
    packageOpts:[],
	mainList:[],
	pkgList:[],
	dlgs:{main:false,pkg:false}
}},
created(){
    var end=new Date();
    this.beginTime=end.getTime()-7*86400000;
    var start=new Date(this.beginTime);
    this.dateStr=start.getFullYear()+'-'+(start.getMonth()+1)+'-'+start.getDate()
     +"  "+end.getFullYear()+'-'+(end.getMonth()+1)+'-'+end.getDate();
},
mounted(){
	//必须Vue.markRaw，否则首次会出错，提示‘Cannot read properties of undefined (reading ‘type‘)’
    this.mainCharts=Vue.markRaw(echarts.init(document.getElementById('mainCharts')));
    this.pkgCharts=Vue.markRaw(echarts.init(document.getElementById('pkgCharts')));
    this.query_main();
    this.service.getPackages().then(function(data){
        this.packageOpts=data.opts;
        this.pkgId=data.pkgs[0].id;
        this.query_pkg();
    }.bind(this)).catch(function(err) {
        Console.info(err);
    });
},
methods:{
query_main() {
    var beginTime=Math.ceil(this.beginTime/7200000);
    var url="/api/report/main?beginTime="+beginTime+"&days="+this.days;
    request({method:"GET",url:url}, this.service.name).then(function(resp){
		var list=resp.code==RetCode.OK?resp.data.data:[];
        //reportAt,vipNum,revenue,orderNum,logNum
        var vipNum=[];
        var revenue=[];
        var orderNum=[];
        var logNum=[];
        var reportAt=[];
        var dt=new Date();
        var foreDay='', dayNo;
		var xDt;
		var mainList=[];

        for(var l of list) {
            dt.setTime(l[0]*7200000);
            dayNo=(dt.getMonth()+1)+'.'+dt.getDate();
			
            if(foreDay==dayNo) {
				xDt=dt.getHours()+':00';
            } else {
				xDt=dayNo+'/'+dt.getHours()+':00';
                foreDay=dayNo;
            }
            reportAt.push(xDt);
            vipNum.push(l[1]);
            revenue.push(l[2]);
            orderNum.push(l[3]);
            logNum.push(l[4]);
			mainList.push([dt.toLocaleString(), l[1], l[2], l[3], l[4]])
        }
        this.mainList = mainList;
        var series=[
            {name:this.tags.revenue,type:'line',data:revenue,yAxisIndex:1,itemStyle:{color:"#ff0011"}}, //新增收入
            {name:this.tags.orderNum,type:'bar',data:orderNum,yAxisIndex:0,itemStyle:{color:"#11ff00"}}, //新增会员(个)
            {name:this.tags.orderNum,type:'bar',data:orderNum,yAxisIndex:0,itemStyle:{color:"#0011ff"}} //新增订单
        ];
        
        this.mainCharts.setOption({
            title: {show:false},
            tooltip: {},
            legend:{},
            xAxis: {data:reportAt},
            yAxis: [{name:this.tags.unitT},{name:this.tags.unitY}],
            series: series
        });
    }.bind(this))
},
query_pkg() {
    var beginTime=Math.ceil(this.beginTime/86400000);
    var url="/api/report/package?beginTime="+beginTime+"&days="+this.days+"&pkgId="+this.pkgId;
    request({method:"GET",url:url}, this.service.name).then(function(resp){
		var list=resp.code==RetCode.OK?resp.data.data:[];
        //reportAt,revenue,orderNum,orderBal,logNum,logVal
        var revenue=[];
        var orderBal=[];
        var orderNum=[];
        var logNum=[];
        var logVal=[];
        var reportAt=[];
        var dt=new Date();
		var xDt;
		var pkgList=[];
        
        for(var l of list) {
            dt.setTime(l[0]*86400000);
			xDt = (dt.getMonth()+1)+'.'+dt.getDate();
            reportAt.push(xDt);
            revenue.push(l[1]);
            orderNum.push(l[2]);
            orderBal.push(l[3]);
            logNum.push(l[4]);
            logVal.push(l[5]);
			pkgList.push([xDt, l[1], l[2], l[3], l[4], l[5]]);
        }
        var series=[
            {name:this.tags.revenue,type:'line',data:revenue,yAxisIndex:1,itemStyle:{color:"#ff0011"}},
            {name:this.tags.orderBal,type:'bar',data:orderBal,yAxisIndex:1,stack:'ClassHour'},
            {name:this.tags.logVal,type:'bar',data:logVal,yAxisIndex:1,stack:'ClassHour'},
            {name:this.tags.orderNum,type:'bar',data:orderNum,yAxisIndex:0},
            {name:this.tags.logNum,type:'bar',data:logNum,yAxisIndex:0}
        ];
        
        this.pkgCharts.setOption({
            title: {show:false},
            tooltip: {},
            legend:{},
            xAxis: {data:reportAt},
            yAxis: [{name:this.tags.unitT},{name:this.tags.unitY}],
            series: series
        });
    }.bind(this))
},
pkg_changed() {
    this.query_pkg();
},
date_range_end(range) {
    var f=range.from;
    var t=range.to;
    this.dateStr=f.year+'/'+f.month+'/'+f.day + "  " + t.year+'/'+t.month+'/'+t.day;
    
    var ft=new Date(f.year,f.month-1,f.day);
    var tt=new Date(t.year,t.month-1,t.day);
    this.beginTime=ft.getTime();
    this.days = Math.ceil((tt.getTime()-this.beginTime)/86400000);
    if(this.days <= 31) {
        this.query_pkg();
        this.query_main();
    } else {
        this.$refs.errMsg.show(this.tags.exceedsDayNum);
    }
}
},

template:`
<q-layout view="lHh lpr lFf" container style="height:100vh">
  <q-header class="bg-grey-1 text-primary" elevated>
   <q-toolbar>
      <q-btn flat round icon="arrow_back" dense @click="service.go_back"></q-btn>
      <q-toolbar-title>{{tags.reports}}</q-toolbar-title>
   </q-toolbar>
  </q-header>
  <q-page-container>
    <q-page class="q-pa-md">
    
<q-input filled v-model="dateStr">
  <template v-slot:prepend>
    <q-icon name="event" class="cursor-pointer">
      <q-popup-proxy transition-show="scale" transition-hide="scale">
        <q-date v-model="date" range @range-end="date_range_end">
          <div class="row items-center justify-end">
            <q-btn v-close-popup :label="tags.close" color="primary" flat />
          </div>
        </q-date>
      </q-popup-proxy>
    </q-icon>
  </template>
</q-input>
<div class="text-h6">{{tags.mainReports}}<q-icon name="list" @click="dlgs.main=true" color="primary" class="q-ml-lg"></q-icon></div>
<div id="mainCharts" :style="{width:'100vw', height:'40vh'}"></div>
<q-space></q-space>
<q-select v-model="pkgId" emit-value map-options :options="packageOpts" @update:model-value="pkg_changed"></q-select>
<div class="text-h6">{{tags.pkgReports}}<q-icon name="list" @click="dlgs.pkg=true" color="primary" class="q-ml-lg"></q-icon></div>
<div id="pkgCharts" :style="{width:'100vw', height:'40vh'}"></div>
    </q-page>
  </q-page-container>
</q-layout>

<q-dialog v-model="dlgs.main">
 <q-card>
  <q-card-section class="row items-center q-pb-none">
   <div class="text-h6">{{tags.mainReports}}</div>
   <q-space></q-space>
   <q-btn icon="close" flat round dense v-close-popup></q-btn>
  </q-card-section>
  <q-card-section class="q-pt-none">
   <q-markup-table flat bordered><tbody>
	 <thead><tr>
	  <th>{{tags.reportAt}}</th>
	  <th>{{tags.vipNum}}</th>
	  <th>{{tags.revenue}}</th>
	  <th>{{tags.orderNum}}</th>
	  <th>{{tags.logNum}}</th>
	 </tr></thead>
	 <tbody><tr v-for="l in mainList" clickable>
	  <td>{{l[0]}}</td>
	  <td>{{l[1]}}</td>
	  <td>{{l[2]}}</td>
	  <td>{{l[3]}}</td>
	  <td>{{l[4]}}</td>
	 </tr></tbody>
  </q-markup-table>
 </q-card>
</q-dialog>

<q-dialog v-model="dlgs.pkg" style="min-width:60vw;">
 <q-card>
  <q-card-section class="row items-center q-pb-none">
   <div class="text-h6">{{tags.pkgReports}}</div>
   <q-space></q-space>
   <q-btn icon="close" flat round dense v-close-popup></q-btn>
  </q-card-section>
  <q-card-section class="q-pt-none">
   <q-markup-table flat bordered><tbody>
	 <thead><tr>
	  <th>{{tags.reportAt}}</th>
	  <th>{{tags.revenue}}</th>
	  <th>{{tags.orderNum}}</th>
	  <th>{{tags.orderBal}}</th>
	  <th>{{tags.logNum}}</th>
	  <th>{{tags.logVal}}</th>
	 </tr></thead>
	 <tbody><tr v-for="l in pkgList" clickable>
	  <td>{{l[0]}}</td>
	  <td>{{l[1]}}</td>
	  <td>{{l[2]}}</td>
	  <td>{{l[3]}}</td>
	  <td>{{l[4]}}</td>
	  <td>{{l[5]}}</td>
	 </tr></tbody>
  </q-markup-table>
 </q-card>
</q-dialog>

<component-alert-dialog :title="tags.failToCall" :errMsgs="tags.errMsgs" :close="tags.close" ref="errMsg"></component-alert-dialog>
`
}